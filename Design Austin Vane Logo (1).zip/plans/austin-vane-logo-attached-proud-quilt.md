# Austin Vane Premium Fashion E-Commerce Website

## Context
The user has provided the Austin Vane brand guidelines and logo (`src/imports/Austin_Vane_Final_Logo.png`) and wants a complete, production-ready premium fashion e-commerce website built for the brand. The app starts from a blank `App.tsx` and needs to be built from scratch using the detailed brand spec.

---

## Brand Tokens (to override theme.css)

Override `src/styles/theme.css` CSS variables to match Austin Vane palette:
- `--background: #FFFFFF`
- `--foreground: #111111`
- `--primary: #111111` (matte black)
- `--primary-foreground: #FFFFFF`
- `--accent: #D8C3A5` (warm beige)
- Add custom vars: `--av-gold: #C9A227`, `--av-beige: #D8C3A5`, `--av-light-gray: #F5F5F5`, `--av-charcoal: #333333`

## Font Setup

Add to `src/styles/fonts.css`:
```css
@import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&family=Inter:wght@400;500&display=swap');
```
Apply `font-family: 'Montserrat', sans-serif` to headings, `'Inter', sans-serif` to body in theme.css.

---

## Architecture

Use **React Router v7** (already installed) for multi-page navigation.

### Pages
| Route | Component File | Description |
|---|---|---|
| `/` | `pages/HomePage.tsx` | Full homepage with all sections |
| `/products/:category?` | `pages/ProductListPage.tsx` | Product grid with filters |
| `/product/:id` | `pages/ProductDetailPage.tsx` | Product detail |
| `/checkout` | `pages/CheckoutPage.tsx` | 4-step checkout |
| `/order-confirmation` | `pages/OrderConfirmationPage.tsx` | Order success |
| `/account` | `pages/AccountPage.tsx` | Account dashboard |
| `/contact` | `pages/ContactPage.tsx` | Contact + FAQ |

### Global State (React Context in `context/AppContext.tsx`)
- `cart`: `CartItem[]` (id, name, size, color, qty, price, image) — persisted to `localStorage`
- `wishlist`: `string[]` (product IDs) — persisted to `localStorage`
- `darkMode`: `boolean`
- `cartOpen`: `boolean` (cart drawer visibility)
- `searchOpen`: `boolean`

---

## Component Files

### Layout
- `components/Header.tsx` — sticky 70px nav; logo left, menu center, icons right; mobile: hamburger + slide-out drawer
- `components/Footer.tsx` — 4-column grid; newsletter, social icons, copyright, payment badges
- `components/CartDrawer.tsx` — 400px right slide-out; items, qty controls, discount code, total, checkout CTA

### Homepage Sections
- `components/HeroSlider.tsx` — full-viewport height slideshow, 5s crossfade, pause on hover; headlines + 3 CTAs; Unsplash fashion images
- `components/FeaturedCategories.tsx` — 7 category cards with dark overlay, gold arrow hover, image zoom
- `components/BestSellers.tsx` — 4-column product grid with cards (image, name, stars, price, add to cart, wishlist)
- `components/NewCollectionBanner.tsx` — split layout editorial section
- `components/WhyChooseUs.tsx` — 6 feature cards on gray bg, gold icons
- `components/Testimonials.tsx` — 3 review cards auto-carousel

### Product Components
- `components/ProductCard.tsx` — reusable card (image 300×400, name, rating, price, badges, wishlist, add to cart)
- `components/ProductGallery.tsx` — main + thumbnails, hover zoom
- `components/SizeSelector.tsx` — XS–XXL button group
- `components/ColorSelector.tsx` — 40px circle swatches
- `components/StarRating.tsx` — gold filled/empty stars

### Checkout Components
- `components/checkout/ProgressBar.tsx` — 4-step indicator
- `components/checkout/ShippingForm.tsx` — fields with react-hook-form
- `components/checkout/DeliveryMethod.tsx` — radio cards
- `components/checkout/PaymentMethod.tsx` — card/UPI/COD options

---

## Mock Data File

`data/products.ts` — 12+ products with id, name, category, price, originalPrice, discount, rating, reviewCount, images, sizes, colors, stock

---

## Key Implementation Details

### Logo Import
```tsx
import logoSrc from "../../imports/Austin_Vane_Final_Logo.png";
```
The logo is dark/black embossed — display with `invert` CSS filter when on dark backgrounds, keep as-is on white backgrounds. Use `ImageWithFallback` from `components/figma/ImageWithFallback.tsx`.

### Cart Persistence
On every cart update: `localStorage.setItem('av_cart', JSON.stringify(cart))`
On init: read from `localStorage.getItem('av_cart')`

### Unsplash Images
Use `mcp__plugin_make_unsplash__search_photos` to fetch real fashion photography for:
- Hero slides: "luxury fashion editorial"
- Category cards: per-category (t-shirt, polo, denim, jacket, etc.)
- Product images: "premium menswear white background"

### Routing Setup
`App.tsx` wraps everything in `<BrowserRouter>` with `<Routes>` + shared `<Header>` / `<Footer>` + `<CartDrawer>`.

---

## Files to Create / Modify

| File | Action |
|---|---|
| `src/styles/theme.css` | Update CSS vars for Austin Vane palette |
| `src/styles/fonts.css` | Add Montserrat + Inter Google Fonts import |
| `src/app/App.tsx` | Router setup, AppContext provider, Header/Footer/CartDrawer wrapper |
| `src/app/context/AppContext.tsx` | Create — global cart/wishlist/darkMode state |
| `src/app/data/products.ts` | Create — mock product catalog |
| `src/app/pages/HomePage.tsx` | Create — assembles all homepage sections |
| `src/app/pages/ProductListPage.tsx` | Create — grid + filters + sort |
| `src/app/pages/ProductDetailPage.tsx` | Create — gallery + info + tabs |
| `src/app/pages/CheckoutPage.tsx` | Create — 4-step wizard |
| `src/app/pages/OrderConfirmationPage.tsx` | Create |
| `src/app/pages/ContactPage.tsx` | Create — FAQ accordion + contact form |
| `src/app/components/Header.tsx` | Create |
| `src/app/components/Footer.tsx` | Create |
| `src/app/components/CartDrawer.tsx` | Create |
| `src/app/components/HeroSlider.tsx` | Create |
| `src/app/components/FeaturedCategories.tsx` | Create |
| `src/app/components/BestSellers.tsx` | Create |
| `src/app/components/NewCollectionBanner.tsx` | Create |
| `src/app/components/WhyChooseUs.tsx` | Create |
| `src/app/components/Testimonials.tsx` | Create |
| `src/app/components/ProductCard.tsx` | Create |
| `src/app/components/ProductGallery.tsx` | Create |
| `src/app/components/StarRating.tsx` | Create |
| `src/app/components/SizeSelector.tsx` | Create |
| `src/app/components/ColorSelector.tsx` | Create |
| `src/app/components/checkout/` | Create 4 step components |

### Reuse Existing UI Components
- `src/app/components/ui/button.tsx` — Button (primary/outline variants)
- `src/app/components/ui/input.tsx` — Input fields in forms
- `src/app/components/ui/dialog.tsx` — Quick view modal, search overlay
- `src/app/components/ui/accordion.tsx` — FAQ section, product detail tabs
- `src/app/components/ui/badge.tsx` — Discount badges, stock status
- `src/app/components/ui/carousel.tsx` — Testimonials carousel
- `src/app/components/ui/sheet.tsx` — Cart drawer (if exists, else custom)
- `src/app/components/figma/ImageWithFallback.tsx` — All images

---

## Verification

1. Homepage renders all sections (hero slides, categories, best sellers, banner, features, reviews, footer)
2. Header shows logo, nav links, and cart/wishlist count badges
3. Clicking a category/product navigates to the correct route
4. Add to Cart updates cart count in header and opens cart drawer
5. Cart drawer shows items with quantity controls; persists on page refresh
6. Checkout progresses through 4 steps; order confirmation page shows at end
7. Dark mode toggle changes to dark theme
8. Mobile responsive: hamburger menu, stacked grid, full-screen cart
