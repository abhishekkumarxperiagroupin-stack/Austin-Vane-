export interface Product {
  id: string;
  name: string;
  category: string;
  subcategory: string;
  price: number;
  originalPrice?: number;
  discount?: number;
  rating: number;
  reviewCount: number;
  images: string[];
  sizes: string[];
  colors: { name: string; hex: string }[];
  stock: number;
  isNew?: boolean;
  isBestSeller?: boolean;
  description: string;
  fabric: string;
  fit: string;
}

const BASE = "https://images.unsplash.com";

export const products: Product[] = [
  {
    id: "p1",
    name: "Classic Matte Black Oversized Tee",
    category: "men",
    subcategory: "Oversized Tees",
    price: 1299,
    originalPrice: 1599,
    discount: 19,
    rating: 4.8,
    reviewCount: 312,
    images: [
      `${BASE}/photo-1661080561444-a0139edfc4f7?w=600&q=80`,
      `${BASE}/photo-1731595758583-8f7b460bc3cb?w=600&q=80`,
    ],
    sizes: ["XS", "S", "M", "L", "XL", "XXL"],
    colors: [
      { name: "Black", hex: "#111111" },
      { name: "White", hex: "#FFFFFF" },
      { name: "Charcoal", hex: "#333333" },
    ],
    stock: 45,
    isBestSeller: true,
    description:
      "Crafted from 100% premium ring-spun cotton, this oversized tee offers an effortlessly relaxed silhouette. The matte fabric resists pilling and maintains its shape through multiple washes, making it the cornerstone of any modern wardrobe.",
    fabric: "100% Ring-Spun Cotton, 240 GSM",
    fit: "Oversized",
  },
  {
    id: "p2",
    name: "Premium Slim Polo — Navy",
    category: "men",
    subcategory: "Polos",
    price: 1899,
    originalPrice: 2299,
    discount: 17,
    rating: 4.7,
    reviewCount: 198,
    images: [
      `${BASE}/photo-1623200470420-e7546d2f786c?w=600&q=80`,
      `${BASE}/photo-1665832102183-b232574131ff?w=600&q=80`,
    ],
    sizes: ["S", "M", "L", "XL", "XXL"],
    colors: [
      { name: "Navy", hex: "#003153" },
      { name: "White", hex: "#FFFFFF" },
      { name: "Beige", hex: "#D8C3A5" },
    ],
    stock: 30,
    isBestSeller: true,
    description:
      "Our signature polo is engineered for the modern professional. Featuring a two-button placket, ribbed collar, and side vents for ease of movement. The piqué weave ensures breathability and structure.",
    fabric: "95% Pima Cotton, 5% Elastane",
    fit: "Slim",
  },
  {
    id: "p3",
    name: "Linen Blend Summer Shirt",
    category: "men",
    subcategory: "Shirts",
    price: 2499,
    rating: 4.6,
    reviewCount: 145,
    images: [
      `${BASE}/photo-1731595759092-4703fd8c4ed1?w=600&q=80`,
      `${BASE}/photo-1649532354755-d6e6ba515703?w=600&q=80`,
    ],
    sizes: ["S", "M", "L", "XL"],
    colors: [
      { name: "White", hex: "#FFFFFF" },
      { name: "Beige", hex: "#D8C3A5" },
      { name: "Sage", hex: "#8FAF8F" },
    ],
    stock: 22,
    isNew: true,
    description:
      "The perfect summer companion. Our linen blend shirt breathes naturally, softens with wear, and drapes beautifully. Available in relaxed and regular fits for every occasion.",
    fabric: "55% Linen, 45% Cotton",
    fit: "Regular",
  },
  {
    id: "p4",
    name: "Slim Stretch Chinos — Khaki",
    category: "men",
    subcategory: "Trousers",
    price: 2999,
    originalPrice: 3499,
    discount: 14,
    rating: 4.5,
    reviewCount: 87,
    images: [
      `${BASE}/photo-1665832102183-b232574131ff?w=600&q=80`,
      `${BASE}/photo-1661080561444-a0139edfc4f7?w=600&q=80`,
    ],
    sizes: ["28", "30", "32", "34", "36"],
    colors: [
      { name: "Khaki", hex: "#C3B091" },
      { name: "Black", hex: "#111111" },
      { name: "Navy", hex: "#003153" },
    ],
    stock: 18,
    isBestSeller: true,
    description:
      "Tailored for the modern man with a 2% elastane blend for all-day comfort. These slim chinos transition effortlessly from office to weekend, featuring a tailored waistband and subtle side seam detail.",
    fabric: "98% Cotton, 2% Elastane",
    fit: "Slim",
  },
  {
    id: "p5",
    name: "Raw Selvedge Denim Jacket",
    category: "men",
    subcategory: "Jackets",
    price: 5999,
    originalPrice: 7499,
    discount: 20,
    rating: 4.9,
    reviewCount: 234,
    images: [
      `${BASE}/photo-1602293589930-45aad59ba3ab?w=600&q=80`,
      `${BASE}/photo-1637069585336-827b298fe84a?w=600&q=80`,
    ],
    sizes: ["S", "M", "L", "XL", "XXL"],
    colors: [
      { name: "Indigo", hex: "#3F51B5" },
      { name: "Black", hex: "#111111" },
    ],
    stock: 12,
    isBestSeller: true,
    description:
      "A heritage piece reimagined. Our raw selvedge denim jacket uses Japanese loom-woven fabric that develops a unique patina over time. With contrast stitching, brass hardware, and a structured silhouette.",
    fabric: "100% Selvedge Denim, 12oz",
    fit: "Regular",
  },
  {
    id: "p6",
    name: "Relaxed Fit T-Shirt — White",
    category: "men",
    subcategory: "T-Shirts",
    price: 999,
    rating: 4.4,
    reviewCount: 456,
    images: [
      `${BASE}/photo-1731595758583-8f7b460bc3cb?w=600&q=80`,
      `${BASE}/photo-1661080561444-a0139edfc4f7?w=600&q=80`,
    ],
    sizes: ["XS", "S", "M", "L", "XL", "XXL"],
    colors: [
      { name: "White", hex: "#FFFFFF" },
      { name: "Black", hex: "#111111" },
      { name: "Grey", hex: "#888888" },
    ],
    stock: 80,
    isNew: true,
    description:
      "The foundational tee. Crafted from GOTS-certified organic cotton with a relaxed fit that works with everything. Pre-washed for softness right out of the package.",
    fabric: "100% Organic Cotton, 200 GSM",
    fit: "Relaxed",
  },
  {
    id: "p7",
    name: "Women's Structured Blazer",
    category: "women",
    subcategory: "Jackets",
    price: 4999,
    originalPrice: 5999,
    discount: 17,
    rating: 4.8,
    reviewCount: 178,
    images: [
      `${BASE}/photo-1613915617430-8ab0fd7c6baf?w=600&q=80`,
      `${BASE}/photo-1603400521630-9f2de124b33b?w=600&q=80`,
    ],
    sizes: ["XS", "S", "M", "L", "XL"],
    colors: [
      { name: "Black", hex: "#111111" },
      { name: "Beige", hex: "#D8C3A5" },
      { name: "White", hex: "#FFFFFF" },
    ],
    stock: 20,
    isBestSeller: true,
    description:
      "Power dressing redefined. This structured single-breasted blazer features peak lapels, a nipped waist, and padded shoulders. Fully lined in satin for a luxurious drape.",
    fabric: "70% Wool, 30% Polyester",
    fit: "Tailored",
  },
  {
    id: "p8",
    name: "Flowy Maxi Dress — Crimson",
    category: "women",
    subcategory: "Dresses",
    price: 3499,
    rating: 4.7,
    reviewCount: 203,
    images: [
      `${BASE}/photo-1580478491436-fd6a937acc9e?w=600&q=80`,
      `${BASE}/photo-1546536133-d1b07a9c768e?w=600&q=80`,
    ],
    sizes: ["XS", "S", "M", "L"],
    colors: [
      { name: "Crimson", hex: "#DC143C" },
      { name: "Navy", hex: "#003153" },
      { name: "Black", hex: "#111111" },
    ],
    stock: 15,
    isNew: true,
    description:
      "Effortless elegance for every occasion. This maxi dress features a wrap silhouette, adjustable tie waist, and V-neck. The crêpe fabric flows beautifully and resists wrinkles.",
    fabric: "100% Viscose Crêpe",
    fit: "Relaxed",
  },
  {
    id: "p9",
    name: "Women's Premium Polo",
    category: "women",
    subcategory: "Polos",
    price: 1699,
    originalPrice: 1999,
    discount: 15,
    rating: 4.6,
    reviewCount: 92,
    images: [
      `${BASE}/photo-1664076458686-3449062080ac?w=600&q=80`,
      `${BASE}/photo-1603400521630-9f2de124b33b?w=600&q=80`,
    ],
    sizes: ["XS", "S", "M", "L", "XL"],
    colors: [
      { name: "White", hex: "#FFFFFF" },
      { name: "Blush", hex: "#FFB6C1" },
      { name: "Sage", hex: "#8FAF8F" },
    ],
    stock: 35,
    isBestSeller: true,
    description:
      "Our women's polo is cut for a feminine silhouette with a slightly longer back hem and a stretch piqué fabric that moves with you. Perfect for sport, leisure, or dressed up with trousers.",
    fabric: "95% Pima Cotton, 5% Elastane",
    fit: "Slim",
  },
  {
    id: "p10",
    name: "High-Rise Slim Denim",
    category: "women",
    subcategory: "Denim",
    price: 3299,
    originalPrice: 3999,
    discount: 18,
    rating: 4.7,
    reviewCount: 267,
    images: [
      `${BASE}/photo-1637069585336-827b298fe84a?w=600&q=80`,
      `${BASE}/photo-1602293589930-45aad59ba3ab?w=600&q=80`,
    ],
    sizes: ["26", "28", "30", "32"],
    colors: [
      { name: "Light Blue", hex: "#ADD8E6" },
      { name: "Dark Wash", hex: "#1a1a4e" },
      { name: "Black", hex: "#111111" },
    ],
    stock: 28,
    isBestSeller: true,
    description:
      "The perfect everyday jean. A high-rise waist and slim leg create a flattering silhouette, while a touch of stretch ensures all-day comfort. Finished with raw hem and authentic whiskering.",
    fabric: "99% Cotton, 1% Elastane",
    fit: "Slim",
  },
  {
    id: "p11",
    name: "Cashmere Blend Oversized Sweater",
    category: "women",
    subcategory: "T-Shirts",
    price: 4299,
    rating: 4.9,
    reviewCount: 134,
    images: [
      `${BASE}/photo-1546536133-d1b07a9c768e?w=600&q=80`,
      `${BASE}/photo-1445205170230-053b83016050?w=600&q=80`,
    ],
    sizes: ["XS", "S", "M", "L", "XL"],
    colors: [
      { name: "Camel", hex: "#C19A6B" },
      { name: "Ivory", hex: "#FFFFF0" },
      { name: "Charcoal", hex: "#333333" },
    ],
    stock: 10,
    isNew: true,
    description:
      "Luxuriously soft and effortlessly chic. Our cashmere blend sweater features a dropped shoulder, ribbed cuffs and hem, and a cozy oversized fit. The 20% cashmere content gives unmatched softness.",
    fabric: "80% Wool, 20% Cashmere",
    fit: "Oversized",
  },
  {
    id: "p12",
    name: "Utility Cargo Trousers",
    category: "men",
    subcategory: "Trousers",
    price: 3499,
    originalPrice: 4299,
    discount: 19,
    rating: 4.5,
    reviewCount: 89,
    images: [
      `${BASE}/photo-1623200470420-e7546d2f786c?w=600&q=80`,
      `${BASE}/photo-1665832102183-b232574131ff?w=600&q=80`,
    ],
    sizes: ["28", "30", "32", "34", "36"],
    colors: [
      { name: "Olive", hex: "#556B2F" },
      { name: "Black", hex: "#111111" },
      { name: "Sand", hex: "#C2B280" },
    ],
    stock: 25,
    isNew: true,
    description:
      "Functional meets fashionable. These utility cargo trousers feature six pockets, an elasticated waistband, and tapered legs for a contemporary silhouette. Constructed from a durable ripstop cotton blend.",
    fabric: "65% Cotton, 35% Polyester Ripstop",
    fit: "Regular",
  },
];

export const categories = [
  {
    id: "premium-tshirts",
    name: "Premium T-Shirts",
    slug: "t-shirts",
    image: `${BASE}/photo-1731595758583-8f7b460bc3cb?w=600&q=80`,
  },
  {
    id: "oversized-tees",
    name: "Oversized Tees",
    slug: "oversized-tees",
    image: `${BASE}/photo-1661080561444-a0139edfc4f7?w=600&q=80`,
  },
  {
    id: "polos",
    name: "Polos",
    slug: "polos",
    image: `${BASE}/photo-1623200470420-e7546d2f786c?w=600&q=80`,
  },
  {
    id: "shirts",
    name: "Shirts",
    slug: "shirts",
    image: `${BASE}/photo-1731595759092-4703fd8c4ed1?w=600&q=80`,
  },
  {
    id: "denim",
    name: "Denim",
    slug: "denim",
    image: `${BASE}/photo-1602293589930-45aad59ba3ab?w=600&q=80`,
  },
  {
    id: "jackets",
    name: "Jackets",
    slug: "jackets",
    image: `${BASE}/photo-1665832102183-b232574131ff?w=600&q=80`,
  },
  {
    id: "new-arrivals",
    name: "New Arrivals",
    slug: "new-arrivals",
    image: `${BASE}/photo-1613915617430-8ab0fd7c6baf?w=600&q=80`,
  },
];
