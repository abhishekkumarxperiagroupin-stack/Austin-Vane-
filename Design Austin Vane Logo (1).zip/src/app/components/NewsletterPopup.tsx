import { useState, useEffect } from "react";
import { X } from "lucide-react";

export function NewsletterPopup() {
  const [visible, setVisible] = useState(false);
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    const dismissed = sessionStorage.getItem("av_newsletter_dismissed");
    if (!dismissed) {
      const timer = setTimeout(() => setVisible(true), 15000);
      return () => clearTimeout(timer);
    }
  }, []);

  const dismiss = () => {
    setVisible(false);
    sessionStorage.setItem("av_newsletter_dismissed", "1");
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(dismiss, 2500);
  };

  if (!visible) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={dismiss} />
      <div
        className="relative bg-white rounded-2xl overflow-hidden shadow-2xl w-full max-w-md"
        style={{ fontFamily: "'Inter', sans-serif" }}
      >
        <div className="h-2" style={{ background: "var(--av-gold)" }} />
        <button onClick={dismiss} className="absolute top-3 right-3 p-1 rounded-full hover:bg-gray-100">
          <X size={18} color="var(--av-charcoal)" />
        </button>
        <div className="p-8 text-center">
          <p className="text-xs font-bold uppercase tracking-widest mb-2" style={{ color: "var(--av-gold)" }}>
            Exclusive Offer
          </p>
          <h2
            className="font-bold mb-2"
            style={{ fontFamily: "'Montserrat', sans-serif", fontSize: "1.6rem", color: "var(--av-black)" }}
          >
            Get 10% OFF
          </h2>
          <p className="text-sm mb-6" style={{ color: "var(--av-charcoal)" }}>
            Subscribe to the Austin Vane newsletter for exclusive drops, style guides, and your first order discount.
          </p>
          {submitted ? (
            <p className="font-bold text-base" style={{ color: "var(--av-gold)" }}>
              ✓ Welcome to the Austin Vane community!
            </p>
          ) : (
            <form onSubmit={handleSubmit} className="flex flex-col gap-3">
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email address"
                className="w-full px-4 py-3 text-sm rounded-md border outline-none"
                style={{ borderColor: "rgba(0,0,0,0.2)", fontFamily: "'Inter', sans-serif" }}
              />
              <button
                type="submit"
                className="w-full py-3 text-sm font-bold rounded-md transition-all hover:opacity-90"
                style={{ background: "var(--av-black)", color: "white", fontFamily: "'Montserrat', sans-serif" }}
              >
                Claim My 10% OFF
              </button>
            </form>
          )}
          <button onClick={dismiss} className="mt-3 text-xs underline" style={{ color: "#9CA3AF" }}>
            No thanks
          </button>
        </div>
      </div>
    </div>
  );
}
