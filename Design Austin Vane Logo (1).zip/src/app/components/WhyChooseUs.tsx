import { Package, Ruler, Leaf, Zap, Shield, RefreshCw } from "lucide-react";

const features = [
  {
    icon: Package,
    title: "Premium Fabrics",
    description: "Highest quality materials sourced globally — GOTS certified, sustainably produced.",
  },
  {
    icon: Ruler,
    title: "Perfect Fit",
    description: "Precision tailoring for every body type with our comprehensive size guide.",
  },
  {
    icon: Leaf,
    title: "Sustainable Manufacturing",
    description: "Eco-conscious production with reduced carbon footprint and ethical labor.",
  },
  {
    icon: Zap,
    title: "Fast Shipping",
    description: "Delivery within 2–3 business days. Free shipping on orders above ₹1000.",
  },
  {
    icon: Shield,
    title: "Secure Payments",
    description: "SSL/TLS encrypted, PCI-DSS Level 1 compliant. Pay with confidence.",
  },
  {
    icon: RefreshCw,
    title: "Easy Returns",
    description: "30-day hassle-free returns. No questions asked, full refund guaranteed.",
  },
];

export function WhyChooseUs() {
  return (
    <section className="py-14 px-4" style={{ background: "var(--av-light-gray)" }}>
      <div className="mx-auto" style={{ maxWidth: "1200px" }}>
        <div className="text-center mb-10">
          <p className="text-xs font-bold uppercase tracking-widest mb-1" style={{ color: "var(--av-gold)" }}>
            Why Austin Vane
          </p>
          <h2
            className="font-bold"
            style={{ fontFamily: "'Montserrat', sans-serif", fontSize: "clamp(1.5rem, 3vw, 2.25rem)", color: "var(--av-black)" }}
          >
            The Austin Vane Promise
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {features.map((feature) => {
            const Icon = feature.icon;
            return (
              <div
                key={feature.title}
                className="group bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-all duration-300 hover:-translate-y-1"
                style={{ fontFamily: "'Inter', sans-serif" }}
              >
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center mb-4 transition-colors duration-300"
                  style={{ background: "rgba(201,162,39,0.12)" }}
                >
                  <Icon size={24} color="var(--av-gold)" />
                </div>
                <h3
                  className="font-bold mb-1.5"
                  style={{ fontFamily: "'Montserrat', sans-serif", fontSize: "1rem", color: "var(--av-black)" }}
                >
                  {feature.title}
                </h3>
                <p className="text-sm leading-relaxed" style={{ color: "var(--av-charcoal)" }}>
                  {feature.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
