interface StarRatingProps {
  rating: number;
  size?: "sm" | "md";
}

export function StarRating({ rating, size = "md" }: StarRatingProps) {
  const starSize = size === "sm" ? "text-xs" : "text-sm";
  return (
    <div className={`flex items-center gap-0.5 ${starSize}`}>
      {[1, 2, 3, 4, 5].map((star) => (
        <span
          key={star}
          style={{ color: star <= Math.round(rating) ? "var(--av-gold)" : "#D1D5DB" }}
        >
          ★
        </span>
      ))}
    </div>
  );
}
