import { ArrowRight } from "lucide-react";
import { Link } from "react-router";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function NewCollectionBanner() {
  return (
    <section className="py-14 px-4" style={{ background: "var(--av-white)" }}>
      <div className="mx-auto" style={{ maxWidth: "1200px" }}>
        <div className="grid lg:grid-cols-2 gap-0 rounded-xl overflow-hidden shadow-lg">
          {/* Image side */}
          <div className="relative overflow-hidden" style={{ minHeight: "440px" }}>
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1603400521630-9f2de124b33b?w=900&q=80"
              alt="Summer Collection 2026"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0" style={{ background: "linear-gradient(135deg, rgba(0,0,0,0.15), transparent)" }} />
          </div>

          {/* Text side */}
          <div
            className="flex flex-col justify-center px-10 py-12"
            style={{ background: "var(--av-black)" }}
          >
            <span
              className="inline-block text-xs font-bold uppercase tracking-widest mb-4 px-3 py-1 rounded-full w-fit"
              style={{ background: "rgba(201,162,39,0.2)", color: "var(--av-gold)", border: "1px solid var(--av-gold)" }}
            >
              Summer 2026
            </span>
            <h2
              className="font-bold text-white leading-tight mb-4"
              style={{ fontFamily: "'Montserrat', sans-serif", fontSize: "clamp(1.75rem, 3.5vw, 3rem)" }}
            >
              Summer Collection<br />2026
            </h2>
            <p
              className="mb-8 leading-relaxed"
              style={{ color: "rgba(255,255,255,0.7)", fontFamily: "'Inter', sans-serif", fontSize: "1rem", maxWidth: "380px" }}
            >
              Crafted for confidence, designed for everyday luxury. Discover pieces that define modern elegance and move with you through every season.
            </p>

            <div className="flex flex-wrap gap-4 mb-8">
              {["Lightweight Fabrics", "Bold Silhouettes", "Versatile Styling"].map((tag) => (
                <span
                  key={tag}
                  className="text-xs font-medium flex items-center gap-1.5"
                  style={{ color: "rgba(255,255,255,0.65)" }}
                >
                  <span style={{ color: "var(--av-gold)" }}>✓</span> {tag}
                </span>
              ))}
            </div>

            <Link
              to="/products/new-arrivals"
              className="inline-flex items-center gap-2 px-8 py-3.5 rounded-md text-sm font-bold w-fit transition-all hover:scale-105 hover:shadow-lg hover:shadow-yellow-900/30"
              style={{ background: "var(--av-gold)", color: "var(--av-black)", fontFamily: "'Montserrat', sans-serif" }}
            >
              Explore Collection <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
