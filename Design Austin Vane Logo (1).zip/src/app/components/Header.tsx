import { useState } from "react";
import { Link, useNavigate } from "react-router";
import { Search, Heart, User, ShoppingBag, Menu, X, Moon, Sun } from "lucide-react";
import { useApp } from "../context/AppContext";
import logoSrc from "../../imports/Austin_Vane_Final_Logo.png";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const navLinks = [
  { label: "Men", href: "/products/men" },
  { label: "Women", href: "/products/women" },
  { label: "New Arrivals", href: "/products/new-arrivals" },
  { label: "Collections", href: "/products" },
  { label: "Best Sellers", href: "/products/best-sellers" },
  { label: "About Us", href: "/about" },
  { label: "Contact", href: "/contact" },
];

export function Header() {
  const { cartCount, wishlistCount, darkMode, toggleDarkMode, setCartOpen, setSearchOpen } = useApp();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const navigate = useNavigate();

  return (
    <>
      <header
        className="sticky top-0 z-50 bg-white border-b"
        style={{ borderColor: "rgba(0,0,0,0.08)", height: "70px", fontFamily: "'Montserrat', sans-serif" }}
      >
        <div
          className="mx-auto flex items-center justify-between h-full px-6"
          style={{ maxWidth: "1200px" }}
        >
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 shrink-0">
            <ImageWithFallback
              src={logoSrc}
              alt="Austin Vane"
              className="h-10 w-auto object-contain"
              style={{ filter: "invert(1) brightness(0)" }}
            />
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center gap-6">
            {navLinks.map((link) => (
              <Link
                key={link.label}
                to={link.href}
                className="text-sm font-medium transition-colors duration-200 hover:text-yellow-600"
                style={{ color: "var(--av-charcoal)", fontFamily: "'Montserrat', sans-serif" }}
              >
                {link.label}
              </Link>
            ))}
          </nav>

          {/* Icons */}
          <div className="flex items-center gap-1">
            <button
              onClick={() => setSearchOpen(true)}
              className="p-2 rounded-md hover:bg-gray-100 transition-colors"
              aria-label="Search"
            >
              <Search size={20} color="var(--av-black)" />
            </button>

            <Link to="/account" className="p-2 rounded-md hover:bg-gray-100 transition-colors hidden sm:flex">
              <User size={20} color="var(--av-black)" />
            </Link>

            <Link to="/wishlist" className="p-2 rounded-md hover:bg-gray-100 transition-colors relative hidden sm:flex">
              <Heart size={20} color="var(--av-black)" />
              {wishlistCount > 0 && (
                <span
                  className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full flex items-center justify-center text-white"
                  style={{ fontSize: "10px", background: "var(--av-gold)" }}
                >
                  {wishlistCount}
                </span>
              )}
            </Link>

            <button
              onClick={() => setCartOpen(true)}
              className="p-2 rounded-md hover:bg-gray-100 transition-colors relative"
              aria-label="Cart"
            >
              <ShoppingBag size={20} color="var(--av-black)" />
              {cartCount > 0 && (
                <span
                  className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full flex items-center justify-center text-white"
                  style={{ fontSize: "10px", background: "var(--av-black)" }}
                >
                  {cartCount}
                </span>
              )}
            </button>

            <button
              onClick={toggleDarkMode}
              className="p-2 rounded-md hover:bg-gray-100 transition-colors hidden sm:flex"
              aria-label="Toggle dark mode"
            >
              {darkMode ? <Sun size={18} color="var(--av-gold)" /> : <Moon size={18} color="var(--av-charcoal)" />}
            </button>

            {/* Mobile hamburger */}
            <button
              className="p-2 rounded-md hover:bg-gray-100 transition-colors lg:hidden"
              onClick={() => setMobileMenuOpen(true)}
              aria-label="Menu"
            >
              <Menu size={22} color="var(--av-black)" />
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 flex">
          <div
            className="absolute inset-0 bg-black/40"
            onClick={() => setMobileMenuOpen(false)}
          />
          <div
            className="relative w-72 h-full bg-white shadow-xl flex flex-col"
            style={{ fontFamily: "'Montserrat', sans-serif" }}
          >
            <div className="flex items-center justify-between p-5 border-b" style={{ borderColor: "rgba(0,0,0,0.08)" }}>
              <ImageWithFallback
                src={logoSrc}
                alt="Austin Vane"
                className="h-8 w-auto object-contain"
                style={{ filter: "invert(1) brightness(0)" }}
              />
              <button onClick={() => setMobileMenuOpen(false)}>
                <X size={22} color="var(--av-black)" />
              </button>
            </div>
            <nav className="flex-1 overflow-y-auto py-4">
              {navLinks.map((link) => (
                <Link
                  key={link.label}
                  to={link.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className="block px-6 py-3 text-sm font-semibold border-b transition-colors hover:bg-gray-50"
                  style={{ color: "var(--av-black)", borderColor: "rgba(0,0,0,0.05)" }}
                >
                  {link.label}
                </Link>
              ))}
            </nav>
            <div className="p-5 border-t flex items-center gap-3" style={{ borderColor: "rgba(0,0,0,0.08)" }}>
              <Link to="/account" onClick={() => setMobileMenuOpen(false)} className="flex items-center gap-2 text-sm font-medium">
                <User size={18} /> Account
              </Link>
              <Link to="/wishlist" onClick={() => setMobileMenuOpen(false)} className="flex items-center gap-2 text-sm font-medium">
                <Heart size={18} /> Wishlist {wishlistCount > 0 && `(${wishlistCount})`}
              </Link>
            </div>
          </div>
        </div>
      )}

      {/* Search Overlay */}
      <SearchOverlay />
    </>
  );
}

function SearchOverlay() {
  const { searchOpen, setSearchOpen } = useApp();
  const navigate = useNavigate();
  const [query, setQuery] = useState("");

  if (!searchOpen) return null;

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      setSearchOpen(false);
      navigate(`/products?search=${encodeURIComponent(query.trim())}`);
      setQuery("");
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 px-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setSearchOpen(false)} />
      <div className="relative w-full max-w-2xl bg-white rounded-xl shadow-2xl overflow-hidden">
        <form onSubmit={handleSearch} className="flex items-center gap-3 p-4">
          <Search size={20} color="var(--av-charcoal)" className="shrink-0" />
          <input
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search for products..."
            className="flex-1 outline-none text-base"
            style={{ fontFamily: "'Inter', sans-serif", color: "var(--av-black)" }}
          />
          <button
            type="button"
            onClick={() => setSearchOpen(false)}
            className="p-1 rounded hover:bg-gray-100"
          >
            <X size={18} color="var(--av-charcoal)" />
          </button>
        </form>
        <div className="border-t px-4 py-3" style={{ borderColor: "rgba(0,0,0,0.08)" }}>
          <p className="text-xs" style={{ color: "var(--av-charcoal)", fontFamily: "'Inter', sans-serif" }}>
            Try: "Oversized Tee", "Polo", "Denim Jacket"
          </p>
        </div>
      </div>
    </div>
  );
}
