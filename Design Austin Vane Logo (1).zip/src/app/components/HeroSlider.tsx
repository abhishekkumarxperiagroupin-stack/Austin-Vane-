import { useState, useEffect, useRef } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Link } from "react-router";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const slides = [
  {
    id: 1,
    image: "https://images.unsplash.com/photo-1613915617430-8ab0fd7c6baf?w=1920&q=80",
    headline: "Elevated Everyday Essentials",
    subheadline: "Premium craftsmanship. Timeless design. Made for modern lifestyles.",
    cta1: { label: "Shop Men", href: "/products/men" },
    cta2: { label: "Shop Women", href: "/products/women" },
    align: "center",
  },
  {
    id: 2,
    image: "https://images.unsplash.com/photo-1580478491436-fd6a937acc9e?w=1920&q=80",
    headline: "New Collection 2026",
    subheadline: "Crafted for confidence, designed for everyday luxury.",
    cta1: { label: "Explore Now", href: "/products/new-arrivals" },
    cta2: { label: "Shop Women", href: "/products/women" },
    align: "left",
  },
  {
    id: 3,
    image: "https://images.unsplash.com/photo-1546536133-d1b07a9c768e?w=1920&q=80",
    headline: "The Art of Dressing Well",
    subheadline: "Every piece tells a story of precision and passion.",
    cta1: { label: "New Arrivals", href: "/products/new-arrivals" },
    cta2: { label: "Best Sellers", href: "/products/best-sellers" },
    align: "right",
  },
  {
    id: 4,
    image: "https://images.unsplash.com/photo-1664076458686-3449062080ac?w=1920&q=80",
    headline: "Luxury for the Modern Soul",
    subheadline: "Where contemporary design meets uncompromising quality.",
    cta1: { label: "Shop Men", href: "/products/men" },
    cta2: { label: "Collections", href: "/products" },
    align: "center",
  },
];

export function HeroSlider() {
  const [current, setCurrent] = useState(0);
  const [paused, setPaused] = useState(false);
  const [transitioning, setTransitioning] = useState(false);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const goTo = (idx: number) => {
    if (transitioning) return;
    setTransitioning(true);
    setTimeout(() => {
      setCurrent(idx);
      setTransitioning(false);
    }, 300);
  };

  const next = () => goTo((current + 1) % slides.length);
  const prev = () => goTo((current - 1 + slides.length) % slides.length);

  useEffect(() => {
    if (!paused) {
      intervalRef.current = setInterval(next, 5000);
    }
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [current, paused]);

  const slide = slides[current];
  const align = slide.align === "left" ? "items-start text-left" : slide.align === "right" ? "items-end text-right" : "items-center text-center";

  return (
    <section
      className="relative w-full overflow-hidden"
      style={{ height: "100svh", minHeight: "600px" }}
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
    >
      {/* Background image */}
      <div className={`absolute inset-0 transition-opacity duration-700 ${transitioning ? "opacity-0" : "opacity-100"}`}>
        <ImageWithFallback
          src={slide.image}
          alt={slide.headline}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0" style={{ background: "linear-gradient(to bottom, rgba(0,0,0,0.2) 0%, rgba(0,0,0,0.55) 100%)" }} />
      </div>

      {/* Content */}
      <div className={`relative z-10 flex flex-col justify-center h-full px-8 md:px-16 ${align} gap-5`}>
        <div
          className={`transition-all duration-700 ${transitioning ? "opacity-0 translate-y-4" : "opacity-100 translate-y-0"}`}
          style={{ maxWidth: "680px", ...(slide.align === "right" ? { marginLeft: "auto" } : slide.align === "center" ? { margin: "0 auto" } : {}) }}
        >
          <span
            className="inline-block text-xs font-bold uppercase tracking-widest mb-3 px-3 py-1 rounded-full"
            style={{ background: "rgba(201,162,39,0.25)", color: "var(--av-gold)", border: "1px solid var(--av-gold)" }}
          >
            Austin Vane — Premium Fashion
          </span>
          <h1
            className="font-bold leading-tight text-white mb-3"
            style={{ fontFamily: "'Montserrat', sans-serif", fontSize: "clamp(2rem, 5vw, 3.5rem)" }}
          >
            {slide.headline}
          </h1>
          <p
            className="text-white/80 mb-6"
            style={{ fontFamily: "'Inter', sans-serif", fontSize: "clamp(0.95rem, 1.5vw, 1.15rem)", maxWidth: "480px", ...(slide.align === "right" ? { marginLeft: "auto" } : slide.align === "center" ? { margin: "0 auto 1.5rem" } : {}) }}
          >
            {slide.subheadline}
          </p>
          <div className={`flex flex-wrap gap-3 ${slide.align === "center" ? "justify-center" : slide.align === "right" ? "justify-end" : ""}`}>
            <Link
              to={slide.cta1.href}
              className="px-7 py-3 text-sm font-bold rounded-md transition-all hover:scale-105 hover:shadow-lg"
              style={{ background: "var(--av-black)", color: "white", fontFamily: "'Montserrat', sans-serif" }}
            >
              {slide.cta1.label}
            </Link>
            <Link
              to={slide.cta2.href}
              className="px-7 py-3 text-sm font-bold rounded-md border-2 transition-all hover:scale-105 hover:border-yellow-400 hover:text-yellow-400"
              style={{ borderColor: "white", color: "white", fontFamily: "'Montserrat', sans-serif" }}
            >
              {slide.cta2.label}
            </Link>
          </div>
        </div>
      </div>

      {/* Arrows */}
      <button
        onClick={prev}
        className="absolute left-4 top-1/2 -translate-y-1/2 z-20 p-2.5 rounded-full bg-black/30 backdrop-blur-sm text-white transition-all hover:bg-black/60"
        aria-label="Previous"
      >
        <ChevronLeft size={22} />
      </button>
      <button
        onClick={next}
        className="absolute right-4 top-1/2 -translate-y-1/2 z-20 p-2.5 rounded-full bg-black/30 backdrop-blur-sm text-white transition-all hover:bg-black/60"
        aria-label="Next"
      >
        <ChevronRight size={22} />
      </button>

      {/* Dots */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-20 flex gap-2">
        {slides.map((_, i) => (
          <button
            key={i}
            onClick={() => goTo(i)}
            className="rounded-full transition-all duration-300"
            style={{
              width: i === current ? "28px" : "8px",
              height: "8px",
              background: i === current ? "var(--av-gold)" : "rgba(255,255,255,0.5)",
            }}
            aria-label={`Slide ${i + 1}`}
          />
        ))}
      </div>
    </section>
  );
}
