import { ArrowRight } from "lucide-react";
import { Link } from "react-router";
import { categories } from "../data/products";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function FeaturedCategories() {
  return (
    <section className="py-14 px-4" style={{ background: "var(--av-white)" }}>
      <div className="mx-auto" style={{ maxWidth: "1200px" }}>
        <div className="text-center mb-8">
          <p className="text-xs font-bold uppercase tracking-widest mb-1" style={{ color: "var(--av-gold)" }}>
            Shop by Category
          </p>
          <h2 className="font-bold" style={{ fontFamily: "'Montserrat', sans-serif", fontSize: "clamp(1.5rem, 3vw, 2.25rem)", color: "var(--av-black)" }}>
            Explore Collections
          </h2>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-7 gap-3">
          {categories.map((cat) => (
            <Link
              key={cat.id}
              to={`/products/${cat.slug}`}
              className="group relative rounded-lg overflow-hidden cursor-pointer"
              style={{ aspectRatio: "3/4" }}
            >
              <ImageWithFallback
                src={cat.image}
                alt={cat.name}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
              />
              {/* Dark overlay */}
              <div
                className="absolute inset-0 transition-all duration-300"
                style={{ background: "rgba(0,0,0,0.4)" }}
              />
              <div
                className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-all duration-300"
                style={{ background: "rgba(0,0,0,0.6)" }}
              />

              {/* Label */}
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 p-2 text-center">
                <span
                  className="text-xs font-bold text-white uppercase tracking-wide leading-tight transition-transform duration-300 group-hover:-translate-y-1"
                  style={{ fontFamily: "'Montserrat', sans-serif", textShadow: "0 1px 3px rgba(0,0,0,0.5)" }}
                >
                  {cat.name}
                </span>
                <ArrowRight
                  size={14}
                  color="var(--av-gold)"
                  className="opacity-0 group-hover:opacity-100 transition-all duration-300 translate-y-2 group-hover:translate-y-0"
                />
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
