import { useState } from "react";
import { Heart, ShoppingBag, Eye } from "lucide-react";
import { Link } from "react-router";
import type { Product } from "../data/products";
import { useApp } from "../context/AppContext";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { StarRating } from "./StarRating";

interface ProductCardProps {
  product: Product;
  onQuickView?: (product: Product) => void;
}

export function ProductCard({ product, onQuickView }: ProductCardProps) {
  const { addToCart, toggleWishlist, isWishlisted } = useApp();
  const [hovered, setHovered] = useState(false);
  const wishlisted = isWishlisted(product.id);

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    addToCart({
      id: product.id,
      name: product.name,
      price: product.price,
      originalPrice: product.originalPrice,
      image: product.images[0],
      size: product.sizes[2] ?? product.sizes[0],
      color: product.colors[0].name,
      qty: 1,
      category: product.category,
    });
  };

  const handleWishlist = (e: React.MouseEvent) => {
    e.preventDefault();
    toggleWishlist(product.id);
  };

  return (
    <Link
      to={`/product/${product.id}`}
      className="group relative flex flex-col bg-white rounded-md overflow-hidden transition-shadow hover:shadow-lg"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{ fontFamily: "'Inter', sans-serif" }}
    >
      {/* Image container */}
      <div className="relative overflow-hidden bg-gray-100" style={{ aspectRatio: "3/4" }}>
        <ImageWithFallback
          src={hovered && product.images[1] ? product.images[1] : product.images[0]}
          alt={product.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />

        {/* Badges */}
        <div className="absolute top-2 left-2 flex flex-col gap-1">
          {product.discount && (
            <span
              className="text-xs font-bold px-2 py-0.5 rounded text-white"
              style={{ background: "var(--av-gold)" }}
            >
              {product.discount}% OFF
            </span>
          )}
          {product.isNew && (
            <span
              className="text-xs font-bold px-2 py-0.5 rounded text-white"
              style={{ background: "var(--av-black)" }}
            >
              NEW
            </span>
          )}
          {product.stock < 10 && product.stock > 0 && (
            <span className="text-xs font-bold px-2 py-0.5 rounded text-white bg-orange-500">
              Only {product.stock} left
            </span>
          )}
        </div>

        {/* Wishlist */}
        <button
          onClick={handleWishlist}
          className="absolute top-2 right-2 p-1.5 rounded-full bg-white shadow transition-transform hover:scale-110"
          aria-label="Wishlist"
        >
          <Heart
            size={16}
            fill={wishlisted ? "var(--av-gold)" : "none"}
            color={wishlisted ? "var(--av-gold)" : "var(--av-charcoal)"}
          />
        </button>

        {/* Hover actions */}
        <div
          className={`absolute bottom-0 left-0 right-0 flex gap-2 p-3 transition-all duration-300 ${hovered ? "opacity-100 translate-y-0" : "opacity-0 translate-y-3"}`}
        >
          <button
            onClick={handleAddToCart}
            className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-md text-xs font-bold transition-colors hover:opacity-90"
            style={{ background: "var(--av-black)", color: "white", fontFamily: "'Montserrat', sans-serif" }}
          >
            <ShoppingBag size={14} />
            Add to Cart
          </button>
          {onQuickView && (
            <button
              onClick={(e) => { e.preventDefault(); onQuickView(product); }}
              className="p-2 rounded-md bg-white border transition-colors hover:border-yellow-500"
              style={{ borderColor: "rgba(0,0,0,0.15)" }}
              aria-label="Quick view"
            >
              <Eye size={16} color="var(--av-charcoal)" />
            </button>
          )}
        </div>
      </div>

      {/* Info */}
      <div className="p-3 flex-1 flex flex-col gap-1">
        <p className="text-xs uppercase tracking-wide" style={{ color: "var(--av-gold)" }}>
          {product.subcategory}
        </p>
        <h3 className="text-sm font-semibold line-clamp-2 leading-snug" style={{ color: "var(--av-black)", fontFamily: "'Montserrat', sans-serif" }}>
          {product.name}
        </h3>
        <div className="flex items-center gap-1.5 mt-0.5">
          <StarRating rating={product.rating} size="sm" />
          <span className="text-xs" style={{ color: "#9CA3AF" }}>({product.reviewCount})</span>
        </div>
        <div className="flex items-center gap-2 mt-1">
          <span className="text-base font-bold" style={{ color: "var(--av-black)" }}>
            ₹{product.price.toLocaleString("en-IN")}
          </span>
          {product.originalPrice && (
            <span className="text-sm line-through" style={{ color: "#9CA3AF" }}>
              ₹{product.originalPrice.toLocaleString("en-IN")}
            </span>
          )}
        </div>
        {product.stock === 0 ? (
          <span className="text-xs text-red-500 font-medium">Out of Stock</span>
        ) : (
          <span className="text-xs font-medium" style={{ color: "#22C55E" }}>In Stock</span>
        )}
      </div>
    </Link>
  );
}
