import { useState } from "react";
import { X, ShoppingBag, Heart } from "lucide-react";
import { Link } from "react-router";
import type { Product } from "../data/products";
import { useApp } from "../context/AppContext";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { StarRating } from "./StarRating";

interface QuickViewModalProps {
  product: Product;
  onClose: () => void;
}

export function QuickViewModal({ product, onClose }: QuickViewModalProps) {
  const { addToCart, toggleWishlist, isWishlisted } = useApp();
  const [selectedSize, setSelectedSize] = useState(product.sizes[2] ?? product.sizes[0]);
  const [selectedColor, setSelectedColor] = useState(product.colors[0]);

  const handleAdd = () => {
    addToCart({
      id: product.id,
      name: product.name,
      price: product.price,
      originalPrice: product.originalPrice,
      image: product.images[0],
      size: selectedSize,
      color: selectedColor.name,
      qty: 1,
      category: product.category,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div
        className="relative bg-white rounded-xl overflow-hidden shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto"
        style={{ fontFamily: "'Inter', sans-serif" }}
      >
        <button
          onClick={onClose}
          className="absolute top-3 right-3 z-10 p-1.5 rounded-full bg-white shadow transition-colors hover:bg-gray-100"
        >
          <X size={18} color="var(--av-black)" />
        </button>

        <div className="flex flex-col sm:flex-row">
          {/* Image */}
          <div className="w-full sm:w-5/12 bg-gray-100 shrink-0" style={{ aspectRatio: "3/4" }}>
            <ImageWithFallback
              src={product.images[0]}
              alt={product.name}
              className="w-full h-full object-cover"
            />
          </div>

          {/* Info */}
          <div className="flex-1 p-6 flex flex-col gap-3">
            <p className="text-xs uppercase tracking-widest font-bold" style={{ color: "var(--av-gold)" }}>
              {product.subcategory}
            </p>
            <h2
              className="font-bold leading-snug"
              style={{ fontFamily: "'Montserrat', sans-serif", fontSize: "1.2rem", color: "var(--av-black)" }}
            >
              {product.name}
            </h2>
            <div className="flex items-center gap-2">
              <StarRating rating={product.rating} />
              <span className="text-xs" style={{ color: "#9CA3AF" }}>({product.reviewCount} reviews)</span>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-xl font-bold" style={{ color: "var(--av-black)" }}>
                ₹{product.price.toLocaleString("en-IN")}
              </span>
              {product.originalPrice && (
                <span className="text-sm line-through" style={{ color: "#9CA3AF" }}>
                  ₹{product.originalPrice.toLocaleString("en-IN")}
                </span>
              )}
              {product.discount && (
                <span className="text-xs font-bold px-2 py-0.5 rounded" style={{ background: "var(--av-gold)", color: "var(--av-black)" }}>
                  {product.discount}% OFF
                </span>
              )}
            </div>

            {/* Size */}
            <div>
              <p className="text-xs font-bold uppercase tracking-wide mb-2" style={{ color: "var(--av-charcoal)" }}>
                Size: <span style={{ color: "var(--av-gold)" }}>{selectedSize}</span>
              </p>
              <div className="flex flex-wrap gap-2">
                {product.sizes.map((size) => (
                  <button
                    key={size}
                    onClick={() => setSelectedSize(size)}
                    className="px-3 py-1.5 text-xs font-semibold rounded border transition-all"
                    style={{
                      background: selectedSize === size ? "var(--av-black)" : "white",
                      color: selectedSize === size ? "white" : "var(--av-charcoal)",
                      borderColor: selectedSize === size ? "var(--av-black)" : "rgba(0,0,0,0.2)",
                    }}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>

            {/* Color */}
            <div>
              <p className="text-xs font-bold uppercase tracking-wide mb-2" style={{ color: "var(--av-charcoal)" }}>
                Color: <span style={{ color: "var(--av-gold)" }}>{selectedColor.name}</span>
              </p>
              <div className="flex gap-2">
                {product.colors.map((color) => (
                  <button
                    key={color.name}
                    onClick={() => setSelectedColor(color)}
                    className="w-8 h-8 rounded-full border-2 transition-all"
                    style={{
                      background: color.hex,
                      borderColor: selectedColor.name === color.name ? "var(--av-gold)" : "transparent",
                      outline: selectedColor.name === color.name ? "2px solid var(--av-gold)" : "2px solid transparent",
                      outlineOffset: "2px",
                    }}
                    title={color.name}
                  />
                ))}
              </div>
            </div>

            <div className="flex gap-2 mt-2">
              <button
                onClick={handleAdd}
                className="flex-1 flex items-center justify-center gap-2 py-3 rounded-md text-sm font-bold transition-all hover:opacity-90"
                style={{ background: "var(--av-black)", color: "white", fontFamily: "'Montserrat', sans-serif" }}
              >
                <ShoppingBag size={16} />
                Add to Cart
              </button>
              <button
                onClick={() => toggleWishlist(product.id)}
                className="p-3 rounded-md border-2 transition-all"
                style={{ borderColor: "rgba(0,0,0,0.2)" }}
              >
                <Heart
                  size={18}
                  fill={isWishlisted(product.id) ? "var(--av-gold)" : "none"}
                  color={isWishlisted(product.id) ? "var(--av-gold)" : "var(--av-charcoal)"}
                />
              </button>
            </div>

            <Link
              to={`/product/${product.id}`}
              onClick={onClose}
              className="text-xs text-center underline transition-colors hover:text-yellow-600"
              style={{ color: "var(--av-charcoal)" }}
            >
              View Full Details →
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
