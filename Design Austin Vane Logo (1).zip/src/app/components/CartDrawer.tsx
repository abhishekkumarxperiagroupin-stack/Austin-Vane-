import { useState } from "react";
import { X, Plus, Minus, ShoppingBag, Tag } from "lucide-react";
import { Link } from "react-router";
import { useApp } from "../context/AppContext";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Button } from "./ui/button";

const PROMO_CODES: Record<string, number> = {
  WELCOME10: 10,
  AV20: 20,
  FIRST15: 15,
};

export function CartDrawer() {
  const { cart, cartOpen, setCartOpen, removeFromCart, updateQty, cartTotal } = useApp();
  const [promoCode, setPromoCode] = useState("");
  const [appliedCode, setAppliedCode] = useState<string | null>(null);
  const [promoError, setPromoError] = useState("");

  const shippingFee = cartTotal >= 1000 ? 0 : 99;
  const discountPercent = appliedCode ? PROMO_CODES[appliedCode] : 0;
  const discountAmt = Math.round((cartTotal * discountPercent) / 100);
  const total = cartTotal - discountAmt + shippingFee;

  const applyPromo = () => {
    const code = promoCode.trim().toUpperCase();
    if (PROMO_CODES[code]) {
      setAppliedCode(code);
      setPromoError("");
      setPromoCode("");
    } else {
      setPromoError("Invalid promo code");
    }
  };

  if (!cartOpen) return null;

  return (
    <>
      <div className="fixed inset-0 z-50 flex justify-end">
        <div className="absolute inset-0 bg-black/40" onClick={() => setCartOpen(false)} />
        <div
          className="relative flex flex-col bg-white shadow-2xl w-full max-w-md h-full"
          style={{ fontFamily: "'Inter', sans-serif" }}
        >
          {/* Header */}
          <div
            className="flex items-center justify-between px-5 py-4 border-b"
            style={{ borderColor: "rgba(0,0,0,0.08)" }}
          >
            <div className="flex items-center gap-2">
              <ShoppingBag size={20} color="var(--av-black)" />
              <span
                className="font-semibold text-base"
                style={{ fontFamily: "'Montserrat', sans-serif", color: "var(--av-black)" }}
              >
                Your Cart
              </span>
              {cart.length > 0 && (
                <span
                  className="text-xs px-2 py-0.5 rounded-full text-white"
                  style={{ background: "var(--av-black)" }}
                >
                  {cart.reduce((s, i) => s + i.qty, 0)}
                </span>
              )}
            </div>
            <button
              onClick={() => setCartOpen(false)}
              className="p-1.5 rounded-md hover:bg-gray-100 transition-colors"
            >
              <X size={20} color="var(--av-black)" />
            </button>
          </div>

          {/* Items */}
          <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
            {cart.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full gap-4 text-center">
                <ShoppingBag size={48} color="#D1D5DB" />
                <p className="text-base font-medium" style={{ color: "var(--av-charcoal)" }}>
                  Your cart is empty
                </p>
                <p className="text-sm" style={{ color: "#9CA3AF" }}>
                  Looks like you haven't added anything yet.
                </p>
                <Button
                  onClick={() => setCartOpen(false)}
                  variant="outline"
                  className="mt-2"
                >
                  Continue Shopping
                </Button>
              </div>
            ) : (
              cart.map((item) => (
                <div
                  key={`${item.id}-${item.size}-${item.color}`}
                  className="flex gap-3 pb-4 border-b"
                  style={{ borderColor: "rgba(0,0,0,0.06)" }}
                >
                  <div className="w-16 h-20 rounded-md overflow-hidden shrink-0 bg-gray-100">
                    <ImageWithFallback
                      src={item.image}
                      alt={item.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold truncate" style={{ color: "var(--av-black)", fontFamily: "'Montserrat', sans-serif" }}>
                      {item.name}
                    </p>
                    <p className="text-xs mt-0.5" style={{ color: "#9CA3AF" }}>
                      {item.size} · {item.color}
                    </p>
                    <div className="flex items-center justify-between mt-2">
                      <div className="flex items-center border rounded-md" style={{ borderColor: "rgba(0,0,0,0.15)" }}>
                        <button
                          className="px-2 py-1 hover:bg-gray-50 transition-colors"
                          onClick={() => updateQty(item.id, item.size, item.color, item.qty - 1)}
                        >
                          <Minus size={12} />
                        </button>
                        <span className="px-2 text-sm font-medium">{item.qty}</span>
                        <button
                          className="px-2 py-1 hover:bg-gray-50 transition-colors"
                          onClick={() => updateQty(item.id, item.size, item.color, item.qty + 1)}
                        >
                          <Plus size={12} />
                        </button>
                      </div>
                      <span className="text-sm font-bold" style={{ color: "var(--av-black)" }}>
                        ₹{(item.price * item.qty).toLocaleString("en-IN")}
                      </span>
                    </div>
                  </div>
                  <button
                    onClick={() => removeFromCart(item.id, item.size, item.color)}
                    className="shrink-0 p-1 rounded hover:bg-red-50 transition-colors self-start mt-0.5"
                  >
                    <X size={14} color="#EF4444" />
                  </button>
                </div>
              ))
            )}
          </div>

          {/* Footer summary */}
          {cart.length > 0 && (
            <div className="border-t px-5 py-4 space-y-3" style={{ borderColor: "rgba(0,0,0,0.08)" }}>
              {/* Promo Code */}
              <div className="flex gap-2">
                <div className="flex-1 flex items-center border rounded-md px-3 gap-2" style={{ borderColor: "rgba(0,0,0,0.15)" }}>
                  <Tag size={14} color="var(--av-charcoal)" />
                  <input
                    value={promoCode}
                    onChange={(e) => { setPromoCode(e.target.value); setPromoError(""); }}
                    placeholder="Promo code"
                    className="flex-1 py-2 text-sm outline-none bg-transparent"
                    onKeyDown={(e) => e.key === "Enter" && applyPromo()}
                  />
                </div>
                <button
                  onClick={applyPromo}
                  className="px-3 py-2 text-sm font-medium rounded-md transition-colors"
                  style={{ background: "var(--av-black)", color: "white" }}
                >
                  Apply
                </button>
              </div>
              {promoError && <p className="text-xs text-red-500">{promoError}</p>}
              {appliedCode && (
                <div className="flex items-center justify-between text-xs" style={{ color: "var(--av-gold)" }}>
                  <span>Promo "{appliedCode}" applied ({discountPercent}% OFF)</span>
                  <button onClick={() => setAppliedCode(null)} className="underline">Remove</button>
                </div>
              )}

              <div className="space-y-1.5 text-sm">
                <div className="flex justify-between" style={{ color: "var(--av-charcoal)" }}>
                  <span>Subtotal</span>
                  <span>₹{cartTotal.toLocaleString("en-IN")}</span>
                </div>
                {discountAmt > 0 && (
                  <div className="flex justify-between" style={{ color: "var(--av-gold)" }}>
                    <span>Discount</span>
                    <span>−₹{discountAmt.toLocaleString("en-IN")}</span>
                  </div>
                )}
                <div className="flex justify-between" style={{ color: "var(--av-charcoal)" }}>
                  <span>Shipping</span>
                  <span>{shippingFee === 0 ? <span style={{ color: "#22C55E" }}>FREE</span> : `₹${shippingFee}`}</span>
                </div>
                {cartTotal < 1000 && (
                  <p className="text-xs" style={{ color: "#9CA3AF" }}>
                    Add ₹{(1000 - cartTotal).toLocaleString("en-IN")} more for free shipping
                  </p>
                )}
                <div
                  className="flex justify-between pt-2 border-t font-bold text-base"
                  style={{ borderColor: "rgba(0,0,0,0.08)", color: "var(--av-black)" }}
                >
                  <span>Total</span>
                  <span style={{ color: "var(--av-gold)" }}>₹{total.toLocaleString("en-IN")}</span>
                </div>
                <p className="text-xs" style={{ color: "#9CA3AF" }}>Taxes calculated at checkout</p>
              </div>

              <div className="space-y-2 pt-1">
                <Link
                  to="/checkout"
                  onClick={() => setCartOpen(false)}
                  className="flex items-center justify-center w-full py-3 rounded-md text-sm font-bold transition-all hover:opacity-90"
                  style={{ background: "var(--av-black)", color: "white", fontFamily: "'Montserrat', sans-serif" }}
                >
                  Checkout
                </Link>
                <button
                  onClick={() => setCartOpen(false)}
                  className="w-full py-2.5 rounded-md text-sm font-medium border transition-all hover:bg-gray-50"
                  style={{ borderColor: "var(--av-black)", color: "var(--av-black)", fontFamily: "'Montserrat', sans-serif" }}
                >
                  Continue Shopping
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
