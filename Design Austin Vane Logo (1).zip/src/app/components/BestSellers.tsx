import { useState } from "react";
import { ArrowRight } from "lucide-react";
import { Link } from "react-router";
import { products } from "../data/products";
import { ProductCard } from "./ProductCard";
import { QuickViewModal } from "./QuickViewModal";
import type { Product } from "../data/products";

export function BestSellers() {
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const bestSellers = products.filter((p) => p.isBestSeller).slice(0, 8);

  return (
    <>
      <section className="py-14 px-4" style={{ background: "var(--av-light-gray)" }}>
        <div className="mx-auto" style={{ maxWidth: "1200px" }}>
          <div className="flex items-end justify-between mb-8">
            <div>
              <p className="text-xs font-bold uppercase tracking-widest mb-1" style={{ color: "var(--av-gold)" }}>
                Customer Favorites
              </p>
              <h2
                className="font-bold"
                style={{ fontFamily: "'Montserrat', sans-serif", fontSize: "clamp(1.5rem, 3vw, 2.25rem)", color: "var(--av-black)" }}
              >
                Best Sellers
              </h2>
            </div>
            <Link
              to="/products/best-sellers"
              className="hidden sm:flex items-center gap-1.5 text-sm font-semibold transition-colors hover:text-yellow-600"
              style={{ color: "var(--av-black)", fontFamily: "'Montserrat', sans-serif" }}
            >
              View All <ArrowRight size={16} />
            </Link>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {bestSellers.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onQuickView={setQuickViewProduct}
              />
            ))}
          </div>

          <div className="mt-6 text-center sm:hidden">
            <Link
              to="/products/best-sellers"
              className="inline-flex items-center gap-1.5 px-6 py-2.5 rounded-md text-sm font-bold border-2 transition-all hover:bg-black hover:text-white"
              style={{ borderColor: "var(--av-black)", color: "var(--av-black)", fontFamily: "'Montserrat', sans-serif" }}
            >
              View All Best Sellers <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </section>

      {quickViewProduct && (
        <QuickViewModal
          product={quickViewProduct}
          onClose={() => setQuickViewProduct(null)}
        />
      )}
    </>
  );
}
