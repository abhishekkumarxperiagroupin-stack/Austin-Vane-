import { useState } from "react";
import { Link } from "react-router";
import { Instagram, Facebook, Youtube, Heart } from "lucide-react";
import logoSrc from "../../imports/Austin_Vane_Final_Logo.png";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const footerLinks = {
  company: [
    { label: "About Us", href: "/about" },
    { label: "Careers", href: "/careers" },
    { label: "Sustainability", href: "/sustainability" },
    { label: "Blog", href: "/blog" },
  ],
  customerService: [
    { label: "Contact Us", href: "/contact" },
    { label: "Shipping Info", href: "/shipping" },
    { label: "Returns & Exchanges", href: "/returns" },
    { label: "Size Guide", href: "/size-guide" },
    { label: "FAQ", href: "/contact#faq" },
  ],
  legal: [
    { label: "Privacy Policy", href: "/privacy" },
    { label: "Terms & Conditions", href: "/terms" },
    { label: "Cookie Policy", href: "/cookies" },
    { label: "Refund Policy", href: "/refund" },
  ],
};

export function Footer() {
  const [email, setEmail] = useState("");
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim()) {
      setSubscribed(true);
      setEmail("");
    }
  };

  return (
    <footer style={{ background: "var(--av-black)", color: "var(--av-white)", fontFamily: "'Inter', sans-serif" }}>
      <div className="mx-auto px-6 pt-14 pb-8" style={{ maxWidth: "1200px" }}>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 pb-10 border-b" style={{ borderColor: "rgba(255,255,255,0.1)" }}>
          {/* Company */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-widest mb-4" style={{ color: "var(--av-gold)" }}>Company</h4>
            <ul className="space-y-2.5">
              {footerLinks.company.map((l) => (
                <li key={l.label}>
                  <Link to={l.href} className="text-sm transition-colors hover:text-white" style={{ color: "rgba(255,255,255,0.65)" }}>
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Customer Service */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-widest mb-4" style={{ color: "var(--av-gold)" }}>Customer Service</h4>
            <ul className="space-y-2.5">
              {footerLinks.customerService.map((l) => (
                <li key={l.label}>
                  <Link to={l.href} className="text-sm transition-colors hover:text-white" style={{ color: "rgba(255,255,255,0.65)" }}>
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-widest mb-4" style={{ color: "var(--av-gold)" }}>Legal</h4>
            <ul className="space-y-2.5">
              {footerLinks.legal.map((l) => (
                <li key={l.label}>
                  <Link to={l.href} className="text-sm transition-colors hover:text-white" style={{ color: "rgba(255,255,255,0.65)" }}>
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-widest mb-2" style={{ color: "var(--av-gold)" }}>Join the Community</h4>
            <p className="text-sm mb-4" style={{ color: "rgba(255,255,255,0.65)" }}>
              Get 10% OFF your first order. Exclusive drops, style guides & more.
            </p>
            {subscribed ? (
              <p className="text-sm font-medium" style={{ color: "var(--av-gold)" }}>
                ✓ Thanks for subscribing!
              </p>
            ) : (
              <form onSubmit={handleSubscribe} className="flex flex-col gap-2">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Your email address"
                  required
                  className="w-full px-3 py-2.5 text-sm rounded-md outline-none"
                  style={{ background: "rgba(255,255,255,0.1)", color: "white", border: "1px solid rgba(255,255,255,0.2)" }}
                />
                <button
                  type="submit"
                  className="w-full py-2.5 text-sm font-bold rounded-md transition-all hover:opacity-90"
                  style={{ background: "var(--av-gold)", color: "var(--av-black)", fontFamily: "'Montserrat', sans-serif" }}
                >
                  Subscribe
                </button>
              </form>
            )}

            <div className="flex items-center gap-3 mt-5">
              <a href="#" aria-label="Instagram" className="p-2 rounded-full transition-colors hover:bg-white/10">
                <Instagram size={18} color="rgba(255,255,255,0.7)" />
              </a>
              <a href="#" aria-label="Facebook" className="p-2 rounded-full transition-colors hover:bg-white/10">
                <Facebook size={18} color="rgba(255,255,255,0.7)" />
              </a>
              <a href="#" aria-label="YouTube" className="p-2 rounded-full transition-colors hover:bg-white/10">
                <Youtube size={18} color="rgba(255,255,255,0.7)" />
              </a>
            </div>
          </div>
        </div>

        {/* Bottom row */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-6">
          <div className="flex items-center gap-3">
            <ImageWithFallback
              src={logoSrc}
              alt="Austin Vane"
              className="h-7 w-auto object-contain"
              style={{ filter: "brightness(0) invert(1) opacity(0.7)" }}
            />
            <p className="text-xs" style={{ color: "rgba(255,255,255,0.4)" }}>
              © 2026 Austin Vane. All rights reserved.
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap justify-center">
            {["VISA", "MC", "AmEx", "UPI", "Razorpay", "COD"].map((method) => (
              <span
                key={method}
                className="text-xs px-2 py-0.5 rounded font-medium"
                style={{ background: "rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.6)" }}
              >
                {method}
              </span>
            ))}
          </div>

          <p className="text-xs flex items-center gap-1" style={{ color: "rgba(255,255,255,0.4)" }}>
            Made with <Heart size={10} fill="currentColor" color="var(--av-gold)" /> in India
          </p>
        </div>
      </div>
    </footer>
  );
}
