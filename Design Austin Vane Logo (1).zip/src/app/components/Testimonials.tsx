import { useState, useEffect, useRef } from "react";
import { ChevronLeft, ChevronRight, Quote } from "lucide-react";
import { StarRating } from "./StarRating";

const testimonials = [
  {
    id: 1,
    name: "Rajesh K.",
    location: "Mumbai",
    rating: 5,
    text: "Austin Vane quality rivals international luxury brands. The attention to detail in every stitch is remarkable. My oversized tee is the most comfortable piece I own.",
    product: "Classic Matte Black Oversized Tee",
  },
  {
    id: 2,
    name: "Priya M.",
    location: "Delhi",
    rating: 5,
    text: "The fit and fabric are exceptional. Best purchase this year. I've been searching for a brand that offers this quality at a fair price — Austin Vane delivers.",
    product: "Women's Structured Blazer",
  },
  {
    id: 3,
    name: "Arjun P.",
    location: "Bangalore",
    rating: 5,
    text: "My new favorite fashion brand. Highly recommend! The linen shirt is perfect for our weather — breathable, stylish, and gets better with every wash.",
    product: "Linen Blend Summer Shirt",
  },
  {
    id: 4,
    name: "Kavya S.",
    location: "Chennai",
    rating: 5,
    text: "Fast shipping, beautiful packaging, and the quality exceeded my expectations. The high-rise denim fits perfectly and the stretch is just right.",
    product: "High-Rise Slim Denim",
  },
  {
    id: 5,
    name: "Vikram N.",
    location: "Hyderabad",
    rating: 5,
    text: "Bought the denim jacket as a gift and it was a huge hit. Premium feel, great construction, and the details are spot on. Will definitely order again.",
    product: "Raw Selvedge Denim Jacket",
  },
];

export function Testimonials() {
  const [current, setCurrent] = useState(0);
  const [paused, setPaused] = useState(false);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const next = () => setCurrent((c) => (c + 1) % testimonials.length);
  const prev = () => setCurrent((c) => (c - 1 + testimonials.length) % testimonials.length);

  useEffect(() => {
    if (!paused) {
      intervalRef.current = setInterval(next, 5000);
    }
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [current, paused]);

  return (
    <section
      className="py-14 px-4"
      style={{ background: "var(--av-white)" }}
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
    >
      <div className="mx-auto" style={{ maxWidth: "1200px" }}>
        <div className="text-center mb-10">
          <p className="text-xs font-bold uppercase tracking-widest mb-1" style={{ color: "var(--av-gold)" }}>
            Customer Reviews
          </p>
          <h2
            className="font-bold"
            style={{ fontFamily: "'Montserrat', sans-serif", fontSize: "clamp(1.5rem, 3vw, 2.25rem)", color: "var(--av-black)" }}
          >
            What Our Customers Say
          </h2>
        </div>

        <div className="relative">
          <div className="overflow-hidden">
            <div
              className="flex transition-transform duration-500 ease-in-out"
              style={{ transform: `translateX(-${current * 100}%)` }}
            >
              {testimonials.map((t) => (
                <div
                  key={t.id}
                  className="w-full shrink-0 px-4 md:px-20"
                >
                  <div
                    className="max-w-2xl mx-auto text-center bg-white rounded-2xl p-8 shadow-sm border"
                    style={{ borderColor: "rgba(0,0,0,0.06)", fontFamily: "'Inter', sans-serif" }}
                  >
                    <Quote size={28} color="var(--av-gold)" className="mx-auto mb-4 opacity-60" />
                    <p
                      className="text-base italic leading-relaxed mb-5"
                      style={{ color: "var(--av-charcoal)" }}
                    >
                      "{t.text}"
                    </p>
                    <div className="flex justify-center mb-3">
                      <StarRating rating={t.rating} />
                    </div>
                    <p className="font-bold text-sm" style={{ fontFamily: "'Montserrat', sans-serif", color: "var(--av-black)" }}>
                      {t.name}
                    </p>
                    <p className="text-xs mt-0.5" style={{ color: "#9CA3AF" }}>
                      {t.location} · {t.product}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Nav arrows */}
          <button
            onClick={prev}
            className="absolute left-0 top-1/2 -translate-y-1/2 p-2 rounded-full border transition-all hover:bg-gray-50"
            style={{ borderColor: "rgba(0,0,0,0.15)" }}
          >
            <ChevronLeft size={18} color="var(--av-charcoal)" />
          </button>
          <button
            onClick={next}
            className="absolute right-0 top-1/2 -translate-y-1/2 p-2 rounded-full border transition-all hover:bg-gray-50"
            style={{ borderColor: "rgba(0,0,0,0.15)" }}
          >
            <ChevronRight size={18} color="var(--av-charcoal)" />
          </button>
        </div>

        {/* Dots */}
        <div className="flex justify-center gap-2 mt-6">
          {testimonials.map((_, i) => (
            <button
              key={i}
              onClick={() => setCurrent(i)}
              className="rounded-full transition-all duration-300"
              style={{
                width: i === current ? "24px" : "8px",
                height: "8px",
                background: i === current ? "var(--av-gold)" : "rgba(0,0,0,0.2)",
              }}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
