import { HeroSlider } from "../components/HeroSlider";
import { FeaturedCategories } from "../components/FeaturedCategories";
import { BestSellers } from "../components/BestSellers";
import { NewCollectionBanner } from "../components/NewCollectionBanner";
import { WhyChooseUs } from "../components/WhyChooseUs";
import { Testimonials } from "../components/Testimonials";
import { NewsletterPopup } from "../components/NewsletterPopup";

export function HomePage() {
  return (
    <>
      <HeroSlider />
      <FeaturedCategories />
      <BestSellers />
      <NewCollectionBanner />
      <WhyChooseUs />
      <Testimonials />
      <NewsletterPopup />
    </>
  );
}
