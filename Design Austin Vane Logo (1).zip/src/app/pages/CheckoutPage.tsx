import { useState } from "react";
import { Link, useNavigate } from "react-router";
import { ChevronRight, Check, CreditCard, Smartphone, Building2, Truck } from "lucide-react";
import { useApp } from "../context/AppContext";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";

const STEPS = ["Shipping", "Delivery", "Payment", "Review"];

const INDIAN_STATES = [
  "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh",
  "Delhi", "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jammu & Kashmir",
  "Jharkhand", "Karnataka", "Kerala", "Madhya Pradesh", "Maharashtra",
  "Manipur", "Meghalaya", "Mizoram", "Nagaland", "Odisha", "Punjab",
  "Rajasthan", "Sikkim", "Tamil Nadu", "Telangana", "Tripura",
  "Uttar Pradesh", "Uttarakhand", "West Bengal",
];

interface ShippingData {
  fullName: string; email: string; phone: string;
  address1: string; address2: string; city: string;
  state: string; pincode: string;
}

const emptyShipping: ShippingData = {
  fullName: "", email: "", phone: "", address1: "",
  address2: "", city: "", state: "", pincode: "",
};

export function CheckoutPage() {
  const { cart, cartTotal, clearCart } = useApp();
  const navigate = useNavigate();
  const [step, setStep] = useState(0);
  const [shipping, setShipping] = useState<ShippingData>(emptyShipping);
  const [delivery, setDelivery] = useState<"standard" | "express">("standard");
  const [payment, setPayment] = useState<"card" | "upi" | "netbanking" | "cod">("card");
  const [cardData, setCardData] = useState({ name: "", number: "", expiry: "", cvv: "" });
  const [errors, setErrors] = useState<Partial<ShippingData>>({});
  const [placing, setPlacing] = useState(false);

  const deliveryFee = delivery === "express" ? 150 : 0;
  const shippingFee = cartTotal >= 1000 ? 0 : 99;
  const total = cartTotal + deliveryFee + shippingFee;

  const validateShipping = () => {
    const e: Partial<ShippingData> = {};
    if (!shipping.fullName) e.fullName = "Required";
    if (!shipping.email || !/\S+@\S+\.\S+/.test(shipping.email)) e.email = "Valid email required";
    if (!shipping.phone || !/^\d{10}$/.test(shipping.phone)) e.phone = "10-digit number required";
    if (!shipping.address1) e.address1 = "Required";
    if (!shipping.city) e.city = "Required";
    if (!shipping.state) e.state = "Required";
    if (!shipping.pincode || !/^\d{6}$/.test(shipping.pincode)) e.pincode = "6-digit pincode required";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleNextStep = () => {
    if (step === 0 && !validateShipping()) return;
    if (step < 3) setStep(step + 1);
  };

  const handlePlaceOrder = async () => {
    setPlacing(true);
    await new Promise((r) => setTimeout(r, 1800));
    clearCart();
    navigate("/order-confirmation", {
      state: {
        orderId: `AV-2026-${Math.random().toString(36).substr(2, 6).toUpperCase()}`,
        total,
        shipping,
        delivery,
        payment,
        items: cart,
      },
    });
  };

  const field = (
    key: keyof ShippingData,
    label: string,
    type = "text",
    placeholder = "",
    required = true
  ) => (
    <div className="flex flex-col gap-1">
      <label className="text-xs font-semibold" style={{ color: "var(--av-charcoal)" }}>
        {label} {required && <span className="text-red-500">*</span>}
      </label>
      <input
        type={type}
        value={shipping[key]}
        onChange={(e) => setShipping((s) => ({ ...s, [key]: e.target.value }))}
        placeholder={placeholder}
        className="px-3 py-2.5 text-sm rounded-md border outline-none transition-colors"
        style={{
          borderColor: errors[key] ? "#EF4444" : "rgba(0,0,0,0.2)",
          fontFamily: "'Inter', sans-serif",
        }}
      />
      {errors[key] && <p className="text-xs text-red-500">{errors[key]}</p>}
    </div>
  );

  if (cart.length === 0 && !placing) {
    return (
      <div className="min-h-screen flex items-center justify-center flex-col gap-4">
        <p className="text-base font-semibold" style={{ color: "var(--av-charcoal)" }}>Your cart is empty</p>
        <Link to="/products" className="px-6 py-2.5 rounded-md text-sm font-bold" style={{ background: "var(--av-black)", color: "white" }}>
          Continue Shopping
        </Link>
      </div>
    );
  }

  return (
    <div style={{ background: "var(--av-light-gray)", fontFamily: "'Inter', sans-serif", minHeight: "100vh" }}>
      <div className="mx-auto px-4 py-8" style={{ maxWidth: "1100px" }}>
        {/* Progress bar */}
        <div className="flex items-center justify-center mb-10">
          {STEPS.map((s, i) => (
            <div key={s} className="flex items-center">
              <div className="flex flex-col items-center gap-1">
                <div
                  className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all"
                  style={{
                    background: i < step ? "var(--av-gold)" : i === step ? "var(--av-black)" : "white",
                    color: i <= step ? "white" : "var(--av-charcoal)",
                    border: i > step ? "2px solid rgba(0,0,0,0.2)" : "none",
                  }}
                >
                  {i < step ? <Check size={14} /> : i + 1}
                </div>
                <span className="text-xs font-medium hidden sm:block" style={{ color: i === step ? "var(--av-black)" : "#9CA3AF" }}>
                  {s}
                </span>
              </div>
              {i < STEPS.length - 1 && (
                <div
                  className="w-16 h-0.5 mx-2 mt-0 mb-4"
                  style={{ background: i < step ? "var(--av-gold)" : "rgba(0,0,0,0.15)" }}
                />
              )}
            </div>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main form area */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl p-6 shadow-sm">
              {/* Step 1: Shipping */}
              {step === 0 && (
                <div>
                  <h2 className="font-bold mb-5" style={{ fontFamily: "'Montserrat', sans-serif", fontSize: "1.2rem", color: "var(--av-black)" }}>
                    Shipping Information
                  </h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {field("fullName", "Full Name", "text", "Rajesh Kumar")}
                    {field("email", "Email", "email", "rajesh@example.com")}
                    {field("phone", "Phone Number", "tel", "9876543210")}
                    <div className="sm:col-span-2">{field("address1", "Address Line 1", "text", "123 Main Street")}</div>
                    <div className="sm:col-span-2">{field("address2", "Address Line 2 (optional)", "text", "Apartment, Suite, etc.", false)}</div>
                    {field("city", "City", "text", "Mumbai")}
                    <div className="flex flex-col gap-1">
                      <label className="text-xs font-semibold" style={{ color: "var(--av-charcoal)" }}>State <span className="text-red-500">*</span></label>
                      <select
                        value={shipping.state}
                        onChange={(e) => setShipping((s) => ({ ...s, state: e.target.value }))}
                        className="px-3 py-2.5 text-sm rounded-md border outline-none bg-white"
                        style={{ borderColor: errors.state ? "#EF4444" : "rgba(0,0,0,0.2)" }}
                      >
                        <option value="">Select State</option>
                        {INDIAN_STATES.map((s) => <option key={s} value={s}>{s}</option>)}
                      </select>
                      {errors.state && <p className="text-xs text-red-500">{errors.state}</p>}
                    </div>
                    {field("pincode", "Pincode", "text", "400001")}
                    <div className="flex flex-col gap-1">
                      <label className="text-xs font-semibold" style={{ color: "var(--av-charcoal)" }}>Country</label>
                      <input value="India" disabled className="px-3 py-2.5 text-sm rounded-md border bg-gray-50" style={{ borderColor: "rgba(0,0,0,0.1)", color: "#9CA3AF" }} />
                    </div>
                  </div>
                </div>
              )}

              {/* Step 2: Delivery */}
              {step === 1 && (
                <div>
                  <h2 className="font-bold mb-5" style={{ fontFamily: "'Montserrat', sans-serif", fontSize: "1.2rem", color: "var(--av-black)" }}>
                    Delivery Method
                  </h2>
                  <div className="space-y-3">
                    {[
                      { id: "standard", label: "Standard Delivery", sub: "5–7 business days", price: "FREE", icon: Truck },
                      { id: "express", label: "Express Delivery", sub: "2–3 business days", price: "₹150", icon: Zap },
                    ].map(({ id, label, sub, price, icon: Icon }) => (
                      <label
                        key={id}
                        className="flex items-center gap-4 p-4 rounded-xl border-2 cursor-pointer transition-all"
                        style={{
                          borderColor: delivery === id ? "var(--av-gold)" : "rgba(0,0,0,0.12)",
                          background: delivery === id ? "rgba(201,162,39,0.05)" : "white",
                        }}
                      >
                        <input
                          type="radio"
                          name="delivery"
                          value={id}
                          checked={delivery === id}
                          onChange={() => setDelivery(id as "standard" | "express")}
                          className="accent-yellow-500"
                        />
                        <Icon size={20} color={delivery === id ? "var(--av-gold)" : "var(--av-charcoal)"} />
                        <div className="flex-1">
                          <p className="text-sm font-semibold" style={{ color: "var(--av-black)" }}>{label}</p>
                          <p className="text-xs" style={{ color: "#9CA3AF" }}>{sub}</p>
                        </div>
                        <span className="text-sm font-bold" style={{ color: delivery === id ? "var(--av-gold)" : "var(--av-black)" }}>
                          {price}
                        </span>
                      </label>
                    ))}
                  </div>
                </div>
              )}

              {/* Step 3: Payment */}
              {step === 2 && (
                <div>
                  <h2 className="font-bold mb-5" style={{ fontFamily: "'Montserrat', sans-serif", fontSize: "1.2rem", color: "var(--av-black)" }}>
                    Payment Method
                  </h2>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-5">
                    {[
                      { id: "card", label: "Card", icon: CreditCard },
                      { id: "upi", label: "UPI", icon: Smartphone },
                      { id: "netbanking", label: "Net Banking", icon: Building2 },
                      { id: "cod", label: "Cash on Delivery", icon: Truck },
                    ].map(({ id, label, icon: Icon }) => (
                      <button
                        key={id}
                        onClick={() => setPayment(id as typeof payment)}
                        className="flex flex-col items-center gap-1.5 p-3 rounded-xl border-2 transition-all"
                        style={{
                          borderColor: payment === id ? "var(--av-gold)" : "rgba(0,0,0,0.12)",
                          background: payment === id ? "rgba(201,162,39,0.05)" : "white",
                        }}
                      >
                        <Icon size={20} color={payment === id ? "var(--av-gold)" : "var(--av-charcoal)"} />
                        <span className="text-xs font-medium text-center" style={{ color: payment === id ? "var(--av-gold)" : "var(--av-charcoal)" }}>
                          {label}
                        </span>
                      </button>
                    ))}
                  </div>

                  {payment === "card" && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 rounded-xl border" style={{ borderColor: "rgba(0,0,0,0.1)", background: "var(--av-light-gray)" }}>
                      <div className="sm:col-span-2 flex flex-col gap-1">
                        <label className="text-xs font-semibold" style={{ color: "var(--av-charcoal)" }}>Cardholder Name</label>
                        <input value={cardData.name} onChange={(e) => setCardData((d) => ({ ...d, name: e.target.value }))} placeholder="Rajesh Kumar" className="px-3 py-2.5 text-sm rounded-md border outline-none bg-white" style={{ borderColor: "rgba(0,0,0,0.2)" }} />
                      </div>
                      <div className="sm:col-span-2 flex flex-col gap-1">
                        <label className="text-xs font-semibold" style={{ color: "var(--av-charcoal)" }}>Card Number</label>
                        <input value={cardData.number} onChange={(e) => setCardData((d) => ({ ...d, number: e.target.value }))} placeholder="4242 4242 4242 4242" maxLength={19} className="px-3 py-2.5 text-sm rounded-md border outline-none bg-white font-mono" style={{ borderColor: "rgba(0,0,0,0.2)" }} />
                      </div>
                      <div className="flex flex-col gap-1">
                        <label className="text-xs font-semibold" style={{ color: "var(--av-charcoal)" }}>Expiry (MM/YY)</label>
                        <input value={cardData.expiry} onChange={(e) => setCardData((d) => ({ ...d, expiry: e.target.value }))} placeholder="12/27" maxLength={5} className="px-3 py-2.5 text-sm rounded-md border outline-none bg-white" style={{ borderColor: "rgba(0,0,0,0.2)" }} />
                      </div>
                      <div className="flex flex-col gap-1">
                        <label className="text-xs font-semibold" style={{ color: "var(--av-charcoal)" }}>CVV</label>
                        <input value={cardData.cvv} onChange={(e) => setCardData((d) => ({ ...d, cvv: e.target.value }))} placeholder="•••" maxLength={4} type="password" className="px-3 py-2.5 text-sm rounded-md border outline-none bg-white" style={{ borderColor: "rgba(0,0,0,0.2)" }} />
                      </div>
                      <div className="sm:col-span-2 flex gap-2 flex-wrap">
                        {["SSL Secured", "PCI-DSS L1", "3D Secure"].map((b) => (
                          <span key={b} className="text-xs px-2 py-0.5 rounded-full font-medium" style={{ background: "rgba(34,197,94,0.1)", color: "#15803D" }}>✓ {b}</span>
                        ))}
                      </div>
                    </div>
                  )}
                  {payment === "upi" && (
                    <div className="p-4 rounded-xl border" style={{ borderColor: "rgba(0,0,0,0.1)", background: "var(--av-light-gray)" }}>
                      <div className="flex flex-col gap-1">
                        <label className="text-xs font-semibold" style={{ color: "var(--av-charcoal)" }}>UPI ID</label>
                        <input placeholder="name@upi" className="px-3 py-2.5 text-sm rounded-md border outline-none bg-white" style={{ borderColor: "rgba(0,0,0,0.2)" }} />
                      </div>
                      <p className="text-xs mt-2" style={{ color: "#9CA3AF" }}>Supports PhonePe, Google Pay, BHIM, Paytm</p>
                    </div>
                  )}
                  {payment === "netbanking" && (
                    <div className="p-4 rounded-xl border" style={{ borderColor: "rgba(0,0,0,0.1)", background: "var(--av-light-gray)" }}>
                      <label className="text-xs font-semibold block mb-2" style={{ color: "var(--av-charcoal)" }}>Select Bank</label>
                      <select className="w-full px-3 py-2.5 text-sm rounded-md border outline-none bg-white" style={{ borderColor: "rgba(0,0,0,0.2)" }}>
                        {["HDFC Bank", "ICICI Bank", "Axis Bank", "SBI", "PNB", "Kotak Mahindra"].map((b) => <option key={b}>{b}</option>)}
                      </select>
                    </div>
                  )}
                  {payment === "cod" && (
                    <div className="p-4 rounded-xl border bg-orange-50" style={{ borderColor: "rgba(251,146,60,0.3)" }}>
                      <p className="text-sm" style={{ color: "var(--av-charcoal)" }}>
                        Pay with cash when your order arrives. COD charges of ₹25 may apply.
                      </p>
                    </div>
                  )}
                </div>
              )}

              {/* Step 4: Review */}
              {step === 3 && (
                <div>
                  <h2 className="font-bold mb-5" style={{ fontFamily: "'Montserrat', sans-serif", fontSize: "1.2rem", color: "var(--av-black)" }}>
                    Review Order
                  </h2>
                  <div className="space-y-3 mb-5">
                    {cart.map((item) => (
                      <div key={`${item.id}-${item.size}-${item.color}`} className="flex items-center gap-3">
                        <div className="w-12 h-14 rounded-md overflow-hidden bg-gray-100 shrink-0">
                          <ImageWithFallback src={item.image} alt={item.name} className="w-full h-full object-cover" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-semibold truncate" style={{ color: "var(--av-black)" }}>{item.name}</p>
                          <p className="text-xs" style={{ color: "#9CA3AF" }}>{item.size} · {item.color} · Qty {item.qty}</p>
                        </div>
                        <span className="text-sm font-bold" style={{ color: "var(--av-black)" }}>
                          ₹{(item.price * item.qty).toLocaleString("en-IN")}
                        </span>
                      </div>
                    ))}
                  </div>
                  <div className="border-t pt-4 space-y-2 text-sm" style={{ borderColor: "rgba(0,0,0,0.08)" }}>
                    <div className="flex justify-between" style={{ color: "var(--av-charcoal)" }}><span>Subtotal</span><span>₹{cartTotal.toLocaleString("en-IN")}</span></div>
                    <div className="flex justify-between" style={{ color: "var(--av-charcoal)" }}><span>Shipping</span><span>{shippingFee === 0 ? "FREE" : `₹${shippingFee}`}</span></div>
                    {deliveryFee > 0 && <div className="flex justify-between" style={{ color: "var(--av-charcoal)" }}><span>Express Delivery</span><span>₹{deliveryFee}</span></div>}
                    <div className="flex justify-between font-bold text-base pt-2 border-t" style={{ borderColor: "rgba(0,0,0,0.08)", color: "var(--av-black)" }}>
                      <span>Total</span><span style={{ color: "var(--av-gold)" }}>₹{total.toLocaleString("en-IN")}</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Order summary sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl p-5 shadow-sm sticky top-24">
              <h3 className="font-bold mb-4 text-sm" style={{ fontFamily: "'Montserrat', sans-serif", color: "var(--av-black)" }}>
                Order Summary
              </h3>
              <div className="space-y-3 mb-4 max-h-52 overflow-y-auto">
                {cart.map((item) => (
                  <div key={`${item.id}-${item.size}-${item.color}`} className="flex items-center gap-2">
                    <div className="w-10 h-12 rounded overflow-hidden bg-gray-100 shrink-0">
                      <ImageWithFallback src={item.image} alt={item.name} className="w-full h-full object-cover" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-semibold truncate" style={{ color: "var(--av-black)" }}>{item.name}</p>
                      <p className="text-xs" style={{ color: "#9CA3AF" }}>Qty {item.qty}</p>
                    </div>
                    <span className="text-xs font-bold shrink-0" style={{ color: "var(--av-black)" }}>₹{(item.price * item.qty).toLocaleString("en-IN")}</span>
                  </div>
                ))}
              </div>
              <div className="space-y-1.5 text-xs border-t pt-3 mb-4" style={{ borderColor: "rgba(0,0,0,0.08)" }}>
                <div className="flex justify-between" style={{ color: "var(--av-charcoal)" }}><span>Subtotal</span><span>₹{cartTotal.toLocaleString("en-IN")}</span></div>
                <div className="flex justify-between" style={{ color: "var(--av-charcoal)" }}><span>Shipping</span><span>{shippingFee === 0 ? "FREE" : `₹${shippingFee}`}</span></div>
                {deliveryFee > 0 && <div className="flex justify-between" style={{ color: "var(--av-charcoal)" }}><span>Express</span><span>₹{deliveryFee}</span></div>}
                <div className="flex justify-between font-bold text-sm pt-1.5 border-t" style={{ borderColor: "rgba(0,0,0,0.08)", color: "var(--av-black)" }}>
                  <span>Total</span><span style={{ color: "var(--av-gold)" }}>₹{total.toLocaleString("en-IN")}</span>
                </div>
              </div>

              <div className="flex gap-2">
                {step > 0 && (
                  <button
                    onClick={() => setStep(step - 1)}
                    className="flex-1 py-2.5 rounded-md text-sm font-medium border transition-all hover:bg-gray-50"
                    style={{ borderColor: "rgba(0,0,0,0.2)", color: "var(--av-charcoal)" }}
                  >
                    Back
                  </button>
                )}
                {step < 3 ? (
                  <button
                    onClick={handleNextStep}
                    className="flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-md text-sm font-bold transition-all hover:opacity-90"
                    style={{ background: "var(--av-black)", color: "white", fontFamily: "'Montserrat', sans-serif" }}
                  >
                    Continue <ChevronRight size={16} />
                  </button>
                ) : (
                  <button
                    onClick={handlePlaceOrder}
                    disabled={placing}
                    className="flex-1 py-2.5 rounded-md text-sm font-bold transition-all hover:opacity-90 disabled:opacity-70"
                    style={{ background: "var(--av-gold)", color: "var(--av-black)", fontFamily: "'Montserrat', sans-serif" }}
                  >
                    {placing ? "Placing..." : "Place Order"}
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Fix missing import
function Zap(props: React.SVGProps<SVGSVGElement> & { size?: number; color?: string }) {
  return (
    <svg width={props.size ?? 24} height={props.size ?? 24} viewBox="0 0 24 24" fill="none" stroke={props.color ?? "currentColor"} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
      <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" />
    </svg>
  );
}
