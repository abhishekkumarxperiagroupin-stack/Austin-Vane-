import { useLocation, Link } from "react-router";
import { CheckCircle, Package, MapPin, CreditCard } from "lucide-react";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";
import type { CartItem } from "../context/AppContext";

interface OrderState {
  orderId: string;
  total: number;
  shipping: { fullName: string; address1: string; city: string; state: string; pincode: string };
  delivery: string;
  payment: string;
  items: CartItem[];
}

export function OrderConfirmationPage() {
  const location = useLocation();
  const state = location.state as OrderState | null;

  const today = new Date();
  const deliveryDate = new Date(today);
  deliveryDate.setDate(today.getDate() + (state?.delivery === "express" ? 3 : 7));
  const fmtDate = (d: Date) => d.toLocaleDateString("en-IN", { weekday: "short", day: "numeric", month: "short", year: "numeric" });

  if (!state) {
    return (
      <div className="min-h-screen flex items-center justify-center flex-col gap-4">
        <p style={{ color: "var(--av-charcoal)" }}>No order found.</p>
        <Link to="/" className="px-6 py-2.5 rounded-md text-sm font-bold" style={{ background: "var(--av-black)", color: "white" }}>
          Return Home
        </Link>
      </div>
    );
  }

  return (
    <div style={{ background: "var(--av-light-gray)", minHeight: "100vh", fontFamily: "'Inter', sans-serif" }}>
      <div className="mx-auto px-4 py-10" style={{ maxWidth: "720px" }}>
        {/* Success header */}
        <div className="bg-white rounded-2xl p-8 shadow-sm text-center mb-5">
          <CheckCircle size={56} color="#22C55E" className="mx-auto mb-4" />
          <h1
            className="font-bold mb-1"
            style={{ fontFamily: "'Montserrat', sans-serif", fontSize: "1.75rem", color: "var(--av-black)" }}
          >
            Order Confirmed!
          </h1>
          <p className="text-sm mb-3" style={{ color: "var(--av-charcoal)" }}>
            Thank you for shopping with Austin Vane. Your order has been placed successfully.
          </p>
          <div
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-bold"
            style={{ background: "rgba(201,162,39,0.12)", color: "var(--av-gold)" }}
          >
            Order ID: {state.orderId}
          </div>
        </div>

        {/* Order details grid */}
        <div className="grid sm:grid-cols-3 gap-4 mb-5">
          <div className="bg-white rounded-xl p-5 shadow-sm">
            <div className="flex items-center gap-2 mb-3">
              <Package size={16} color="var(--av-gold)" />
              <p className="text-xs font-bold uppercase tracking-widest" style={{ color: "var(--av-gold)" }}>Delivery</p>
            </div>
            <p className="text-sm font-semibold" style={{ color: "var(--av-black)" }}>
              {state.delivery === "express" ? "Express (2–3 days)" : "Standard (5–7 days)"}
            </p>
            <p className="text-xs mt-1" style={{ color: "#9CA3AF" }}>Expected by {fmtDate(deliveryDate)}</p>
          </div>

          <div className="bg-white rounded-xl p-5 shadow-sm">
            <div className="flex items-center gap-2 mb-3">
              <MapPin size={16} color="var(--av-gold)" />
              <p className="text-xs font-bold uppercase tracking-widest" style={{ color: "var(--av-gold)" }}>Ship to</p>
            </div>
            <p className="text-sm font-semibold" style={{ color: "var(--av-black)" }}>{state.shipping.fullName}</p>
            <p className="text-xs mt-0.5" style={{ color: "#9CA3AF" }}>
              {state.shipping.address1}, {state.shipping.city}, {state.shipping.state} {state.shipping.pincode}
            </p>
          </div>

          <div className="bg-white rounded-xl p-5 shadow-sm">
            <div className="flex items-center gap-2 mb-3">
              <CreditCard size={16} color="var(--av-gold)" />
              <p className="text-xs font-bold uppercase tracking-widest" style={{ color: "var(--av-gold)" }}>Payment</p>
            </div>
            <p className="text-sm font-semibold capitalize" style={{ color: "var(--av-black)" }}>{state.payment}</p>
            <p className="text-xs mt-1 font-bold" style={{ color: "var(--av-gold)" }}>
              ₹{state.total.toLocaleString("en-IN")}
            </p>
          </div>
        </div>

        {/* Items */}
        <div className="bg-white rounded-xl p-5 shadow-sm mb-5">
          <h3 className="font-bold mb-4 text-sm" style={{ fontFamily: "'Montserrat', sans-serif", color: "var(--av-black)" }}>
            Order Items
          </h3>
          <div className="space-y-3">
            {state.items.map((item) => (
              <div key={`${item.id}-${item.size}-${item.color}`} className="flex items-center gap-3">
                <div className="w-12 h-14 rounded-md overflow-hidden bg-gray-100 shrink-0">
                  <ImageWithFallback src={item.image} alt={item.name} className="w-full h-full object-cover" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold truncate" style={{ color: "var(--av-black)" }}>{item.name}</p>
                  <p className="text-xs" style={{ color: "#9CA3AF" }}>{item.size} · {item.color} · Qty {item.qty}</p>
                </div>
                <span className="text-sm font-bold shrink-0" style={{ color: "var(--av-black)" }}>
                  ₹{(item.price * item.qty).toLocaleString("en-IN")}
                </span>
              </div>
            ))}
          </div>
          <div className="flex justify-between font-bold text-sm mt-4 pt-3 border-t" style={{ borderColor: "rgba(0,0,0,0.08)" }}>
            <span style={{ color: "var(--av-black)" }}>Total Paid</span>
            <span style={{ color: "var(--av-gold)" }}>₹{state.total.toLocaleString("en-IN")}</span>
          </div>
        </div>

        {/* Tracking info */}
        <div className="bg-white rounded-xl p-5 shadow-sm mb-6">
          <p className="text-sm" style={{ color: "var(--av-charcoal)" }}>
            📧 A confirmation email has been sent to your registered email address with tracking details.
            You'll receive SMS updates as your order progresses.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <Link
            to="/"
            className="flex-1 text-center py-3 rounded-md text-sm font-bold transition-all hover:opacity-90"
            style={{ background: "var(--av-black)", color: "white", fontFamily: "'Montserrat', sans-serif" }}
          >
            Return to Home
          </Link>
          <Link
            to="/products"
            className="flex-1 text-center py-3 rounded-md text-sm font-bold border-2 transition-all hover:bg-gray-50"
            style={{ borderColor: "var(--av-black)", color: "var(--av-black)", fontFamily: "'Montserrat', sans-serif" }}
          >
            Continue Shopping
          </Link>
        </div>
      </div>
    </div>
  );
}
