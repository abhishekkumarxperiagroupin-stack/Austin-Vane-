import { useState } from "react";
import { User, Package, Heart, MapPin, LogOut } from "lucide-react";
import { Link } from "react-router";
import { useApp } from "../context/AppContext";
import { products } from "../data/products";
import { ProductCard } from "../components/ProductCard";

const TABS = [
  { id: "profile", label: "Profile", icon: User },
  { id: "orders", label: "Orders", icon: Package },
  { id: "wishlist", label: "Wishlist", icon: Heart },
  { id: "addresses", label: "Addresses", icon: MapPin },
];

const MOCK_ORDERS = [
  { id: "AV-2026-X7K3Q1", date: "18 Jun 2026", total: 4198, status: "Delivered", items: 2 },
  { id: "AV-2026-M9P2Z5", date: "05 Jun 2026", total: 2499, status: "Shipped", items: 1 },
  { id: "AV-2026-B4W8N2", date: "22 May 2026", total: 7499, status: "Delivered", items: 3 },
];

const STATUS_COLORS: Record<string, string> = {
  Delivered: "#22C55E",
  Shipped: "#3B82F6",
  Processing: "#F59E0B",
  Cancelled: "#EF4444",
};

export function AccountPage() {
  const [activeTab, setActiveTab] = useState("profile");
  const { wishlist } = useApp();
  const wishlisted = products.filter((p) => wishlist.includes(p.id));

  return (
    <div style={{ background: "var(--av-light-gray)", minHeight: "100vh", fontFamily: "'Inter', sans-serif" }}>
      {/* Header */}
      <div className="py-10 px-4" style={{ background: "var(--av-black)" }}>
        <div className="mx-auto flex items-center gap-4" style={{ maxWidth: "1100px" }}>
          <div
            className="w-14 h-14 rounded-full flex items-center justify-center shrink-0"
            style={{ background: "var(--av-gold)" }}
          >
            <User size={24} color="var(--av-black)" />
          </div>
          <div>
            <p className="text-xs uppercase tracking-widest mb-0.5" style={{ color: "rgba(255,255,255,0.5)" }}>Welcome back</p>
            <h1 className="font-bold text-white" style={{ fontFamily: "'Montserrat', sans-serif", fontSize: "1.3rem" }}>
              Rajesh Kumar
            </h1>
            <p className="text-xs" style={{ color: "rgba(255,255,255,0.5)" }}>rajesh@example.com</p>
          </div>
        </div>
      </div>

      <div className="mx-auto px-4 py-8" style={{ maxWidth: "1100px" }}>
        <div className="flex flex-col md:flex-row gap-6">
          {/* Sidebar tabs */}
          <aside className="md:w-52 shrink-0">
            <div className="bg-white rounded-xl shadow-sm overflow-hidden">
              {TABS.map(({ id, label, icon: Icon }) => (
                <button
                  key={id}
                  onClick={() => setActiveTab(id)}
                  className="w-full flex items-center gap-3 px-4 py-3.5 text-sm font-medium border-b transition-colors hover:bg-gray-50 text-left"
                  style={{
                    borderColor: "rgba(0,0,0,0.06)",
                    color: activeTab === id ? "var(--av-gold)" : "var(--av-charcoal)",
                    background: activeTab === id ? "rgba(201,162,39,0.06)" : "white",
                    borderLeft: activeTab === id ? `3px solid var(--av-gold)` : "3px solid transparent",
                  }}
                >
                  <Icon size={16} color={activeTab === id ? "var(--av-gold)" : "var(--av-charcoal)"} />
                  {label}
                </button>
              ))}
              <button
                className="w-full flex items-center gap-3 px-4 py-3.5 text-sm font-medium text-red-500 hover:bg-red-50 transition-colors"
              >
                <LogOut size={16} /> Sign Out
              </button>
            </div>
          </aside>

          {/* Content */}
          <div className="flex-1">
            {activeTab === "profile" && (
              <div className="bg-white rounded-xl p-6 shadow-sm">
                <h2 className="font-bold mb-5" style={{ fontFamily: "'Montserrat', sans-serif", color: "var(--av-black)" }}>
                  Profile Information
                </h2>
                <div className="grid sm:grid-cols-2 gap-4">
                  {[
                    { label: "Full Name", value: "Rajesh Kumar" },
                    { label: "Email", value: "rajesh@example.com" },
                    { label: "Phone", value: "+91 98765 43210" },
                    { label: "Date of Birth", value: "15 March 1990" },
                  ].map(({ label, value }) => (
                    <div key={label} className="flex flex-col gap-1">
                      <label className="text-xs font-semibold" style={{ color: "var(--av-charcoal)" }}>{label}</label>
                      <input
                        defaultValue={value}
                        className="px-3 py-2.5 text-sm rounded-md border outline-none"
                        style={{ borderColor: "rgba(0,0,0,0.2)" }}
                      />
                    </div>
                  ))}
                </div>
                <button
                  className="mt-5 px-6 py-2.5 rounded-md text-sm font-bold transition-all hover:opacity-90"
                  style={{ background: "var(--av-black)", color: "white", fontFamily: "'Montserrat', sans-serif" }}
                >
                  Save Changes
                </button>
              </div>
            )}

            {activeTab === "orders" && (
              <div className="bg-white rounded-xl p-6 shadow-sm">
                <h2 className="font-bold mb-5" style={{ fontFamily: "'Montserrat', sans-serif", color: "var(--av-black)" }}>
                  Order History
                </h2>
                <div className="space-y-3">
                  {MOCK_ORDERS.map((order) => (
                    <div
                      key={order.id}
                      className="flex items-center justify-between p-4 rounded-xl border transition-all hover:border-yellow-400"
                      style={{ borderColor: "rgba(0,0,0,0.1)" }}
                    >
                      <div>
                        <p className="text-sm font-bold" style={{ color: "var(--av-black)" }}>{order.id}</p>
                        <p className="text-xs mt-0.5" style={{ color: "#9CA3AF" }}>{order.date} · {order.items} item{order.items > 1 ? "s" : ""}</p>
                      </div>
                      <div className="text-right">
                        <span
                          className="text-xs font-bold px-2.5 py-1 rounded-full"
                          style={{ background: `${STATUS_COLORS[order.status]}15`, color: STATUS_COLORS[order.status] }}
                        >
                          {order.status}
                        </span>
                        <p className="text-sm font-bold mt-1" style={{ color: "var(--av-gold)" }}>
                          ₹{order.total.toLocaleString("en-IN")}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === "wishlist" && (
              <div>
                {wishlisted.length === 0 ? (
                  <div className="bg-white rounded-xl p-10 shadow-sm text-center">
                    <Heart size={40} color="#D1D5DB" className="mx-auto mb-3" />
                    <p className="font-semibold mb-1" style={{ color: "var(--av-charcoal)" }}>Your wishlist is empty</p>
                    <Link to="/products" className="text-sm underline" style={{ color: "var(--av-gold)" }}>Browse Products</Link>
                  </div>
                ) : (
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {wishlisted.map((p) => <ProductCard key={p.id} product={p} />)}
                  </div>
                )}
              </div>
            )}

            {activeTab === "addresses" && (
              <div className="bg-white rounded-xl p-6 shadow-sm">
                <h2 className="font-bold mb-5" style={{ fontFamily: "'Montserrat', sans-serif", color: "var(--av-black)" }}>
                  Saved Addresses
                </h2>
                <div
                  className="p-4 rounded-xl border"
                  style={{ borderColor: "var(--av-gold)", background: "rgba(201,162,39,0.04)" }}
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-xs font-bold uppercase tracking-widest mb-1" style={{ color: "var(--av-gold)" }}>Home</p>
                      <p className="text-sm font-semibold" style={{ color: "var(--av-black)" }}>Rajesh Kumar</p>
                      <p className="text-sm" style={{ color: "var(--av-charcoal)" }}>123 Main Street, Andheri West</p>
                      <p className="text-sm" style={{ color: "var(--av-charcoal)" }}>Mumbai, Maharashtra 400053</p>
                      <p className="text-xs mt-1" style={{ color: "#9CA3AF" }}>+91 98765 43210</p>
                    </div>
                    <button className="text-xs underline" style={{ color: "var(--av-gold)" }}>Edit</button>
                  </div>
                </div>
                <button
                  className="mt-4 px-5 py-2.5 rounded-md text-sm font-medium border-2 transition-all hover:bg-gray-50"
                  style={{ borderColor: "var(--av-black)", color: "var(--av-black)" }}
                >
                  + Add New Address
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
