import { useState } from "react";
import { useParams, Link, useNavigate } from "react-router";
import { Heart, ShoppingBag, Share2, Minus, Plus, ZoomIn } from "lucide-react";
import { products } from "../data/products";
import { useApp } from "../context/AppContext";
import { ProductCard } from "../components/ProductCard";
import { StarRating } from "../components/StarRating";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";

const REVIEWS = [
  { name: "Aryan M.", location: "Mumbai", rating: 5, date: "12 Jun 2026", text: "Absolutely love this product. The quality is premium and the fit is perfect. Would highly recommend to anyone looking for quality fashion." },
  { name: "Sneha R.", location: "Bangalore", rating: 5, date: "08 Jun 2026", text: "Great purchase! The fabric feels luxurious and the stitching is immaculate. Delivery was super fast too." },
  { name: "Rohan K.", location: "Delhi", rating: 4, date: "01 Jun 2026", text: "Very good quality. Slightly bigger than expected but the fit guide was accurate. Overall happy with the purchase." },
];

const TABS = ["Details", "Fabric Care", "Shipping & Returns", "Reviews"];

export function ProductDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { addToCart, toggleWishlist, isWishlisted } = useApp();

  const product = products.find((p) => p.id === id);
  const related = products.filter((p) => p.id !== id && p.category === product?.category).slice(0, 4);

  const [selectedImage, setSelectedImage] = useState(0);
  const [selectedSize, setSelectedSize] = useState(product?.sizes[2] ?? product?.sizes[0] ?? "");
  const [selectedColor, setSelectedColor] = useState(product?.colors[0] ?? { name: "", hex: "" });
  const [qty, setQty] = useState(1);
  const [activeTab, setActiveTab] = useState(0);
  const [zoomOpen, setZoomOpen] = useState(false);

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-lg font-semibold mb-3" style={{ color: "var(--av-charcoal)" }}>Product not found</p>
          <button onClick={() => navigate("/products")} className="px-6 py-2.5 rounded-md text-sm font-bold" style={{ background: "var(--av-black)", color: "white" }}>
            Browse Products
          </button>
        </div>
      </div>
    );
  }

  const handleAddToCart = () => {
    addToCart({
      id: product.id,
      name: product.name,
      price: product.price,
      originalPrice: product.originalPrice,
      image: product.images[0],
      size: selectedSize,
      color: selectedColor.name,
      qty,
      category: product.category,
    });
  };

  const handleBuyNow = () => {
    handleAddToCart();
    navigate("/checkout");
  };

  return (
    <div style={{ background: "var(--av-white)", fontFamily: "'Inter', sans-serif" }}>
      {/* Breadcrumb */}
      <div className="px-4 py-3 border-b" style={{ borderColor: "rgba(0,0,0,0.08)" }}>
        <div className="mx-auto flex items-center gap-2 text-xs" style={{ maxWidth: "1200px", color: "var(--av-charcoal)" }}>
          <Link to="/" className="hover:underline">Home</Link>
          <span>/</span>
          <Link to={`/products/${product.category}`} className="hover:underline capitalize">{product.category}</Link>
          <span>/</span>
          <span className="truncate max-w-40">{product.name}</span>
        </div>
      </div>

      <div className="mx-auto px-4 py-8" style={{ maxWidth: "1200px" }}>
        <div className="grid lg:grid-cols-5 gap-8 lg:gap-12">
          {/* Gallery (left 3 cols) */}
          <div className="lg:col-span-3 space-y-3">
            <div
              className="relative rounded-xl overflow-hidden bg-gray-100 cursor-zoom-in"
              style={{ aspectRatio: "3/4" }}
              onClick={() => setZoomOpen(true)}
            >
              <ImageWithFallback
                src={product.images[selectedImage]}
                alt={product.name}
                className="w-full h-full object-cover"
              />
              <button className="absolute bottom-3 right-3 p-1.5 rounded-full bg-white/80 backdrop-blur-sm shadow">
                <ZoomIn size={16} color="var(--av-charcoal)" />
              </button>
              {product.discount && (
                <span
                  className="absolute top-3 left-3 text-xs font-bold px-2 py-1 rounded text-white"
                  style={{ background: "var(--av-gold)" }}
                >
                  {product.discount}% OFF
                </span>
              )}
            </div>
            {/* Thumbnails */}
            {product.images.length > 1 && (
              <div className="flex gap-2">
                {product.images.map((img, i) => (
                  <button
                    key={i}
                    onClick={() => setSelectedImage(i)}
                    className="rounded-md overflow-hidden border-2 transition-all"
                    style={{
                      width: "72px",
                      height: "88px",
                      borderColor: selectedImage === i ? "var(--av-gold)" : "transparent",
                    }}
                  >
                    <ImageWithFallback src={img} alt={`View ${i + 1}`} className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Info (right 2 cols) */}
          <div className="lg:col-span-2 space-y-5">
            <div>
              <p className="text-xs font-bold uppercase tracking-widest mb-1" style={{ color: "var(--av-gold)" }}>
                {product.subcategory}
              </p>
              <h1
                className="font-bold leading-snug mb-2"
                style={{ fontFamily: "'Montserrat', sans-serif", fontSize: "clamp(1.3rem, 2.5vw, 1.75rem)", color: "var(--av-black)" }}
              >
                {product.name}
              </h1>
              <div className="flex items-center gap-2">
                <StarRating rating={product.rating} />
                <span className="text-xs" style={{ color: "#9CA3AF" }}>{product.reviewCount} reviews</span>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <span className="text-2xl font-bold" style={{ color: "var(--av-black)" }}>
                ₹{product.price.toLocaleString("en-IN")}
              </span>
              {product.originalPrice && (
                <span className="text-base line-through" style={{ color: "#9CA3AF" }}>
                  ₹{product.originalPrice.toLocaleString("en-IN")}
                </span>
              )}
              {product.discount && (
                <span className="text-xs font-bold px-2 py-0.5 rounded" style={{ background: "rgba(201,162,39,0.15)", color: "var(--av-gold)" }}>
                  {product.discount}% OFF
                </span>
              )}
            </div>

            <p className="text-sm leading-relaxed" style={{ color: "var(--av-charcoal)" }}>
              {product.description}
            </p>

            {/* Stock */}
            {product.stock > 0 ? (
              <p className="text-xs font-medium" style={{ color: product.stock < 10 ? "#F59E0B" : "#22C55E" }}>
                {product.stock < 10 ? `Only ${product.stock} left in stock` : "In Stock"}
              </p>
            ) : (
              <p className="text-xs font-medium text-red-500">Out of Stock</p>
            )}

            {/* Size */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <p className="text-xs font-bold uppercase tracking-wide" style={{ color: "var(--av-charcoal)" }}>
                  Size: <span style={{ color: "var(--av-gold)" }}>{selectedSize}</span>
                </p>
                <button className="text-xs underline" style={{ color: "var(--av-charcoal)" }}>Size Guide</button>
              </div>
              <div className="flex flex-wrap gap-2">
                {product.sizes.map((size) => (
                  <button
                    key={size}
                    onClick={() => setSelectedSize(size)}
                    className="px-3 py-1.5 text-xs font-semibold rounded border transition-all"
                    style={{
                      background: selectedSize === size ? "var(--av-black)" : "white",
                      color: selectedSize === size ? "white" : "var(--av-charcoal)",
                      borderColor: selectedSize === size ? "var(--av-black)" : "rgba(0,0,0,0.2)",
                    }}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>

            {/* Color */}
            <div>
              <p className="text-xs font-bold uppercase tracking-wide mb-2" style={{ color: "var(--av-charcoal)" }}>
                Color: <span style={{ color: "var(--av-gold)" }}>{selectedColor.name}</span>
              </p>
              <div className="flex gap-2">
                {product.colors.map((color) => (
                  <button
                    key={color.name}
                    onClick={() => setSelectedColor(color)}
                    className="w-9 h-9 rounded-full border-2 transition-all"
                    style={{
                      background: color.hex,
                      borderColor: color.name === selectedColor.name ? "var(--av-gold)" : "transparent",
                      outline: color.name === selectedColor.name ? "2px solid var(--av-gold)" : "2px solid transparent",
                      outlineOffset: "2px",
                      boxShadow: "0 0 0 1px rgba(0,0,0,0.15)",
                    }}
                    title={color.name}
                  />
                ))}
              </div>
            </div>

            {/* Qty */}
            <div>
              <p className="text-xs font-bold uppercase tracking-wide mb-2" style={{ color: "var(--av-charcoal)" }}>Quantity</p>
              <div className="flex items-center border rounded-md w-fit" style={{ borderColor: "rgba(0,0,0,0.2)" }}>
                <button
                  onClick={() => setQty(Math.max(1, qty - 1))}
                  className="px-3 py-2 hover:bg-gray-50 transition-colors"
                >
                  <Minus size={14} />
                </button>
                <span className="px-4 py-2 text-sm font-bold border-x" style={{ borderColor: "rgba(0,0,0,0.1)" }}>{qty}</span>
                <button
                  onClick={() => setQty(Math.min(product.stock, qty + 1))}
                  className="px-3 py-2 hover:bg-gray-50 transition-colors"
                >
                  <Plus size={14} />
                </button>
              </div>
            </div>

            {/* Action buttons */}
            <div className="space-y-2.5">
              <button
                onClick={handleAddToCart}
                disabled={product.stock === 0}
                className="w-full flex items-center justify-center gap-2 py-3.5 rounded-md text-sm font-bold transition-all hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed"
                style={{ background: "var(--av-black)", color: "white", fontFamily: "'Montserrat', sans-serif" }}
              >
                <ShoppingBag size={18} />
                Add to Cart
              </button>
              <button
                onClick={handleBuyNow}
                disabled={product.stock === 0}
                className="w-full flex items-center justify-center gap-2 py-3.5 rounded-md text-sm font-bold border-2 transition-all hover:bg-gray-50 disabled:opacity-50"
                style={{ borderColor: "var(--av-black)", color: "var(--av-black)", fontFamily: "'Montserrat', sans-serif" }}
              >
                Buy Now
              </button>
              <div className="flex gap-2">
                <button
                  onClick={() => toggleWishlist(product.id)}
                  className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-md text-xs font-medium border transition-all hover:bg-gray-50"
                  style={{ borderColor: "rgba(0,0,0,0.15)", color: "var(--av-charcoal)" }}
                >
                  <Heart
                    size={15}
                    fill={isWishlisted(product.id) ? "var(--av-gold)" : "none"}
                    color={isWishlisted(product.id) ? "var(--av-gold)" : "var(--av-charcoal)"}
                  />
                  {isWishlisted(product.id) ? "Wishlisted" : "Wishlist"}
                </button>
                <button
                  className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-md text-xs font-medium border transition-all hover:bg-gray-50"
                  style={{ borderColor: "rgba(0,0,0,0.15)", color: "var(--av-charcoal)" }}
                >
                  <Share2 size={15} />
                  Share
                </button>
              </div>
            </div>

            {/* Trust badges */}
            <div className="flex flex-wrap gap-3 pt-2 border-t" style={{ borderColor: "rgba(0,0,0,0.08)" }}>
              {["Free Shipping >₹1000", "30-Day Returns", "Secure Payment"].map((badge) => (
                <span key={badge} className="text-xs flex items-center gap-1" style={{ color: "var(--av-charcoal)" }}>
                  <span style={{ color: "var(--av-gold)" }}>✓</span> {badge}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="mt-12 border-b" style={{ borderColor: "rgba(0,0,0,0.1)" }}>
          <div className="flex gap-0 overflow-x-auto">
            {TABS.map((tab, i) => (
              <button
                key={tab}
                onClick={() => setActiveTab(i)}
                className="px-5 py-3 text-sm font-semibold whitespace-nowrap transition-all border-b-2"
                style={{
                  borderColor: activeTab === i ? "var(--av-gold)" : "transparent",
                  color: activeTab === i ? "var(--av-gold)" : "var(--av-charcoal)",
                  fontFamily: "'Montserrat', sans-serif",
                }}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>

        <div className="py-8 max-w-2xl">
          {activeTab === 0 && (
            <div className="space-y-3 text-sm" style={{ color: "var(--av-charcoal)" }}>
              <p>{product.description}</p>
              <ul className="list-disc list-inside space-y-1.5 mt-4">
                <li>Fabric: {product.fabric}</li>
                <li>Fit: {product.fit}</li>
                <li>Machine washable at 30°C</li>
                <li>Do not bleach</li>
                <li>Country of origin: India</li>
              </ul>
            </div>
          )}
          {activeTab === 1 && (
            <div className="space-y-2 text-sm" style={{ color: "var(--av-charcoal)" }}>
              <p>To keep your Austin Vane piece looking its best:</p>
              <ul className="list-disc list-inside space-y-1.5 mt-2">
                <li>Machine wash cold with similar colors</li>
                <li>Do not use bleach or fabric softener</li>
                <li>Tumble dry on low heat or air dry flat</li>
                <li>Warm iron on reverse if needed</li>
                <li>Do not dry clean</li>
              </ul>
            </div>
          )}
          {activeTab === 2 && (
            <div className="space-y-4 text-sm" style={{ color: "var(--av-charcoal)" }}>
              <div>
                <p className="font-semibold mb-1" style={{ color: "var(--av-black)" }}>Shipping</p>
                <p>Standard delivery: 5–7 business days (FREE)</p>
                <p>Express delivery: 2–3 business days (₹150)</p>
                <p>Free shipping on orders above ₹1,000</p>
              </div>
              <div>
                <p className="font-semibold mb-1" style={{ color: "var(--av-black)" }}>Returns & Exchanges</p>
                <p>30-day hassle-free returns on unworn items with tags attached. Simply contact us at contact@austinvane.com.</p>
              </div>
            </div>
          )}
          {activeTab === 3 && (
            <div className="space-y-5">
              <div className="flex items-center gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-3xl font-bold" style={{ color: "var(--av-black)" }}>{product.rating}</span>
                    <StarRating rating={product.rating} />
                  </div>
                  <p className="text-xs mt-0.5" style={{ color: "#9CA3AF" }}>{product.reviewCount} reviews</p>
                </div>
              </div>
              {REVIEWS.map((r, i) => (
                <div key={i} className="border-b pb-4" style={{ borderColor: "rgba(0,0,0,0.08)" }}>
                  <div className="flex items-center justify-between mb-1">
                    <p className="text-sm font-semibold" style={{ color: "var(--av-black)", fontFamily: "'Montserrat', sans-serif" }}>{r.name} · {r.location}</p>
                    <span className="text-xs" style={{ color: "#9CA3AF" }}>{r.date}</span>
                  </div>
                  <StarRating rating={r.rating} size="sm" />
                  <p className="text-sm mt-1.5" style={{ color: "var(--av-charcoal)" }}>{r.text}</p>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Related products */}
        {related.length > 0 && (
          <div className="mt-12">
            <h2
              className="font-bold mb-6"
              style={{ fontFamily: "'Montserrat', sans-serif", fontSize: "1.4rem", color: "var(--av-black)" }}
            >
              You Might Also Like
            </h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {related.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Zoom modal */}
      {zoomOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 p-4" onClick={() => setZoomOpen(false)}>
          <ImageWithFallback
            src={product.images[selectedImage]}
            alt={product.name}
            className="max-w-full max-h-full object-contain rounded-lg"
            style={{ maxHeight: "90vh" }}
          />
        </div>
      )}
    </div>
  );
}
