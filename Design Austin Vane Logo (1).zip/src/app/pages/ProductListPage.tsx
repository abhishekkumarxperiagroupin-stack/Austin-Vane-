import { useState, useMemo } from "react";
import { useParams, useSearchParams, Link } from "react-router";
import { SlidersHorizontal, ChevronDown, X } from "lucide-react";
import { products } from "../data/products";
import { ProductCard } from "../components/ProductCard";
import { QuickViewModal } from "../components/QuickViewModal";
import type { Product } from "../data/products";

const SORT_OPTIONS = [
  { value: "newest", label: "Newest" },
  { value: "price-asc", label: "Price: Low to High" },
  { value: "price-desc", label: "Price: High to Low" },
  { value: "rating", label: "Best Rated" },
  { value: "best-sellers", label: "Best Sellers" },
];

const PRICE_RANGES = [
  { label: "Under ₹1,000", min: 0, max: 1000 },
  { label: "₹1,000 – ₹2,000", min: 1000, max: 2000 },
  { label: "₹2,000 – ₹4,000", min: 2000, max: 4000 },
  { label: "Above ₹4,000", min: 4000, max: Infinity },
];

export function ProductListPage() {
  const { category } = useParams<{ category?: string }>();
  const [searchParams] = useSearchParams();
  const searchQuery = searchParams.get("search") ?? "";

  const [sort, setSort] = useState("newest");
  const [selectedPriceRange, setSelectedPriceRange] = useState<number | null>(null);
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const [visibleCount, setVisibleCount] = useState(12);

  const pageTitle = useMemo(() => {
    if (searchQuery) return `Search: "${searchQuery}"`;
    if (!category) return "All Products";
    if (category === "men") return "Men's Collection";
    if (category === "women") return "Women's Collection";
    if (category === "new-arrivals") return "New Arrivals";
    if (category === "best-sellers") return "Best Sellers";
    return category.split("-").map((w) => w.charAt(0).toUpperCase() + w.slice(1)).join(" ");
  }, [category, searchQuery]);

  const filtered = useMemo(() => {
    let list = [...products];

    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      list = list.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.subcategory.toLowerCase().includes(q) ||
          p.category.toLowerCase().includes(q)
      );
    } else if (category === "new-arrivals") {
      list = list.filter((p) => p.isNew);
    } else if (category === "best-sellers") {
      list = list.filter((p) => p.isBestSeller);
    } else if (category === "men" || category === "women") {
      list = list.filter((p) => p.category === category);
    } else if (category) {
      const slug = category.toLowerCase();
      list = list.filter(
        (p) =>
          p.subcategory.toLowerCase().replace(/\s+/g, "-") === slug ||
          p.category === slug
      );
    }

    if (selectedPriceRange !== null) {
      const range = PRICE_RANGES[selectedPriceRange];
      list = list.filter((p) => p.price >= range.min && p.price < range.max);
    }

    switch (sort) {
      case "price-asc": list.sort((a, b) => a.price - b.price); break;
      case "price-desc": list.sort((a, b) => b.price - a.price); break;
      case "rating": list.sort((a, b) => b.rating - a.rating); break;
      case "best-sellers": list.sort((a, b) => (b.isBestSeller ? 1 : 0) - (a.isBestSeller ? 1 : 0)); break;
      default: list.sort((a, b) => (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0));
    }

    return list;
  }, [category, searchQuery, sort, selectedPriceRange]);

  return (
    <>
      <div className="min-h-screen" style={{ background: "var(--av-white)", fontFamily: "'Inter', sans-serif" }}>
        {/* Breadcrumb */}
        <div className="px-4 py-3 border-b" style={{ borderColor: "rgba(0,0,0,0.08)" }}>
          <div className="mx-auto flex items-center gap-2 text-xs" style={{ maxWidth: "1200px", color: "var(--av-charcoal)" }}>
            <Link to="/" className="hover:underline">Home</Link>
            <span>/</span>
            <span>{pageTitle}</span>
          </div>
        </div>

        <div className="mx-auto px-4 py-8" style={{ maxWidth: "1200px" }}>
          {/* Header row */}
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1
                className="font-bold"
                style={{ fontFamily: "'Montserrat', sans-serif", fontSize: "1.5rem", color: "var(--av-black)" }}
              >
                {pageTitle}
              </h1>
              <p className="text-xs mt-0.5" style={{ color: "#9CA3AF" }}>
                {filtered.length} products
              </p>
            </div>

            <div className="flex items-center gap-3">
              {/* Filter toggle (mobile) */}
              <button
                onClick={() => setFiltersOpen(!filtersOpen)}
                className="flex items-center gap-1.5 px-3 py-2 border rounded-md text-sm font-medium transition-colors hover:bg-gray-50 md:hidden"
                style={{ borderColor: "rgba(0,0,0,0.2)", color: "var(--av-black)" }}
              >
                <SlidersHorizontal size={14} /> Filters
              </button>

              {/* Sort */}
              <div className="relative">
                <select
                  value={sort}
                  onChange={(e) => setSort(e.target.value)}
                  className="appearance-none pl-3 pr-8 py-2 border rounded-md text-sm font-medium outline-none cursor-pointer bg-white transition-colors hover:border-yellow-400"
                  style={{ borderColor: "rgba(0,0,0,0.2)", color: "var(--av-black)" }}
                >
                  {SORT_OPTIONS.map((o) => (
                    <option key={o.value} value={o.value}>{o.label}</option>
                  ))}
                </select>
                <ChevronDown size={14} className="absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none" color="var(--av-charcoal)" />
              </div>
            </div>
          </div>

          <div className="flex gap-6">
            {/* Sidebar filters (desktop) */}
            <aside className="hidden md:block w-52 shrink-0">
              <div className="sticky top-24 space-y-6">
                <div>
                  <h3 className="text-xs font-bold uppercase tracking-widest mb-3" style={{ color: "var(--av-charcoal)" }}>
                    Category
                  </h3>
                  {["men", "women"].map((cat) => (
                    <Link
                      key={cat}
                      to={`/products/${cat}`}
                      className="block text-sm py-1 transition-colors hover:text-yellow-600 capitalize"
                      style={{ color: category === cat ? "var(--av-gold)" : "var(--av-charcoal)", fontWeight: category === cat ? "600" : "400" }}
                    >
                      {cat === "men" ? "Men" : "Women"}
                    </Link>
                  ))}
                </div>

                <div>
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-xs font-bold uppercase tracking-widest" style={{ color: "var(--av-charcoal)" }}>
                      Price Range
                    </h3>
                    {selectedPriceRange !== null && (
                      <button onClick={() => setSelectedPriceRange(null)}>
                        <X size={12} color="var(--av-gold)" />
                      </button>
                    )}
                  </div>
                  {PRICE_RANGES.map((range, i) => (
                    <label key={i} className="flex items-center gap-2 py-1 cursor-pointer group">
                      <input
                        type="radio"
                        name="price"
                        checked={selectedPriceRange === i}
                        onChange={() => setSelectedPriceRange(i)}
                        className="accent-yellow-500"
                      />
                      <span className="text-sm transition-colors group-hover:text-yellow-600" style={{ color: "var(--av-charcoal)" }}>
                        {range.label}
                      </span>
                    </label>
                  ))}
                </div>
              </div>
            </aside>

            {/* Mobile filters drawer */}
            {filtersOpen && (
              <div className="fixed inset-0 z-40 md:hidden">
                <div className="absolute inset-0 bg-black/40" onClick={() => setFiltersOpen(false)} />
                <div className="absolute bottom-0 left-0 right-0 bg-white rounded-t-2xl p-5 max-h-96 overflow-y-auto">
                  <h3 className="font-bold mb-4" style={{ fontFamily: "'Montserrat', sans-serif" }}>Filters</h3>
                  <div className="mb-4">
                    <p className="text-xs font-bold uppercase tracking-widest mb-2" style={{ color: "var(--av-charcoal)" }}>Price Range</p>
                    {PRICE_RANGES.map((range, i) => (
                      <label key={i} className="flex items-center gap-2 py-1.5 cursor-pointer">
                        <input type="radio" name="price-mobile" checked={selectedPriceRange === i} onChange={() => setSelectedPriceRange(i)} className="accent-yellow-500" />
                        <span className="text-sm" style={{ color: "var(--av-charcoal)" }}>{range.label}</span>
                      </label>
                    ))}
                  </div>
                  <button
                    onClick={() => setFiltersOpen(false)}
                    className="w-full py-3 rounded-md text-sm font-bold"
                    style={{ background: "var(--av-black)", color: "white" }}
                  >
                    Apply Filters
                  </button>
                </div>
              </div>
            )}

            {/* Product grid */}
            <div className="flex-1">
              {filtered.length === 0 ? (
                <div className="text-center py-20">
                  <p className="text-lg font-semibold mb-2" style={{ color: "var(--av-charcoal)" }}>No products found</p>
                  <Link to="/products" className="text-sm underline" style={{ color: "var(--av-gold)" }}>Browse all products</Link>
                </div>
              ) : (
                <>
                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                    {filtered.slice(0, visibleCount).map((product) => (
                      <ProductCard
                        key={product.id}
                        product={product}
                        onQuickView={setQuickViewProduct}
                      />
                    ))}
                  </div>

                  {visibleCount < filtered.length && (
                    <div className="text-center mt-10">
                      <button
                        onClick={() => setVisibleCount((c) => c + 12)}
                        className="px-8 py-3 rounded-md text-sm font-bold border-2 transition-all hover:bg-black hover:text-white"
                        style={{ borderColor: "var(--av-black)", color: "var(--av-black)", fontFamily: "'Montserrat', sans-serif" }}
                      >
                        Load More ({filtered.length - visibleCount} remaining)
                      </button>
                    </div>
                  )}
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      {quickViewProduct && (
        <QuickViewModal product={quickViewProduct} onClose={() => setQuickViewProduct(null)} />
      )}
    </>
  );
}
