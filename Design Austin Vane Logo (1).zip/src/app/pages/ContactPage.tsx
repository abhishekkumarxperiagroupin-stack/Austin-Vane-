import { useState } from "react";
import { Mail, Phone, MapPin, MessageCircle, ChevronDown } from "lucide-react";

const faqs = [
  {
    q: "What are your shipping options?",
    a: "We offer Standard Delivery (5–7 business days, FREE on orders above ₹1,000) and Express Delivery (2–3 business days, ₹150). Free standard shipping is automatically applied when your cart value exceeds ₹1,000.",
  },
  {
    q: "What is your return policy?",
    a: "We offer a 30-day hassle-free return policy on all unworn items with original tags attached. Simply email us at contact@austinvane.com with your order ID and we'll initiate the return process within 24 hours.",
  },
  {
    q: "How do I find my size?",
    a: "Each product page includes a detailed size guide with measurements in CM and inches. We recommend measuring your chest, waist, and hips and comparing with our size chart. If you're between sizes, we generally recommend sizing up for a relaxed fit.",
  },
  {
    q: "Are your products sustainably made?",
    a: "Yes! Austin Vane is committed to sustainable manufacturing. We use GOTS-certified organic cotton where possible, partner with ethical manufacturers, and are working toward carbon-neutral shipping by 2027.",
  },
  {
    q: "Can I change or cancel my order?",
    a: "Orders can be modified or cancelled within 2 hours of placement. After that, the order enters processing and cannot be changed. Please contact us immediately at contact@austinvane.com if you need to make changes.",
  },
  {
    q: "What payment methods do you accept?",
    a: "We accept Credit/Debit Cards (Visa, Mastercard, AmEx), UPI (PhonePe, Google Pay, BHIM), Net Banking (all major banks via Razorpay), and Cash on Delivery. All online payments are secured with SSL encryption and PCI-DSS Level 1 compliance.",
  },
  {
    q: "How do I track my order?",
    a: "Once your order ships, you'll receive an email and SMS with a tracking link. You can also log into your account and check Order History for real-time updates.",
  },
  {
    q: "Do you offer gift cards?",
    a: "Yes! We offer gift cards in denominations of ₹500, ₹1,000, ₹2,500, and ₹5,000. They can be purchased on our website and sent digitally to the recipient.",
  },
];

export function ContactPage() {
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const [form, setForm] = useState({ name: "", email: "", subject: "", message: "" });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div style={{ background: "var(--av-white)", fontFamily: "'Inter', sans-serif" }}>
      {/* Hero */}
      <div
        className="py-16 px-4 text-center"
        style={{ background: "var(--av-black)" }}
      >
        <p className="text-xs font-bold uppercase tracking-widest mb-2" style={{ color: "var(--av-gold)" }}>
          We're Here to Help
        </p>
        <h1
          className="font-bold text-white mb-3"
          style={{ fontFamily: "'Montserrat', sans-serif", fontSize: "clamp(1.75rem, 4vw, 2.5rem)" }}
        >
          Contact Us
        </h1>
        <p className="text-sm max-w-lg mx-auto" style={{ color: "rgba(255,255,255,0.65)" }}>
          Have questions about your order, sizing, or our products? We'd love to hear from you.
        </p>
      </div>

      <div className="mx-auto px-4 py-12" style={{ maxWidth: "1100px" }}>
        <div className="grid lg:grid-cols-2 gap-12 mb-16">
          {/* Contact info */}
          <div>
            <h2
              className="font-bold mb-6"
              style={{ fontFamily: "'Montserrat', sans-serif", fontSize: "1.4rem", color: "var(--av-black)" }}
            >
              Get in Touch
            </h2>
            <div className="space-y-5 mb-8">
              {[
                { icon: Mail, label: "Email", value: "contact@austinvane.com", sub: "We reply within 24 hours" },
                { icon: Phone, label: "Phone", value: "+91 98765 43210", sub: "Mon–Sat, 10 AM – 8 PM IST" },
                { icon: MapPin, label: "Address", value: "Austin Vane HQ, Mumbai, Maharashtra 400001", sub: "India" },
                { icon: MessageCircle, label: "Live Chat", value: "Available on website", sub: "Mon–Sat, 10 AM – 8 PM IST" },
              ].map(({ icon: Icon, label, value, sub }) => (
                <div key={label} className="flex items-start gap-4">
                  <div
                    className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
                    style={{ background: "rgba(201,162,39,0.12)" }}
                  >
                    <Icon size={18} color="var(--av-gold)" />
                  </div>
                  <div>
                    <p className="text-xs font-bold uppercase tracking-widest mb-0.5" style={{ color: "var(--av-gold)" }}>{label}</p>
                    <p className="text-sm font-medium" style={{ color: "var(--av-black)" }}>{value}</p>
                    <p className="text-xs" style={{ color: "#9CA3AF" }}>{sub}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Contact form */}
          <div>
            <h2
              className="font-bold mb-6"
              style={{ fontFamily: "'Montserrat', sans-serif", fontSize: "1.4rem", color: "var(--av-black)" }}
            >
              Send Us a Message
            </h2>
            {submitted ? (
              <div className="p-8 rounded-xl text-center border" style={{ borderColor: "rgba(0,0,0,0.1)", background: "rgba(34,197,94,0.05)" }}>
                <p className="text-2xl mb-3">✓</p>
                <p className="font-bold text-base mb-1" style={{ fontFamily: "'Montserrat', sans-serif", color: "#15803D" }}>
                  Message Sent!
                </p>
                <p className="text-sm" style={{ color: "var(--av-charcoal)" }}>
                  We've received your message and will get back to you within 24 hours.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="flex flex-col gap-1">
                    <label className="text-xs font-semibold" style={{ color: "var(--av-charcoal)" }}>Name *</label>
                    <input
                      required
                      value={form.name}
                      onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                      placeholder="Your name"
                      className="px-3 py-2.5 text-sm rounded-md border outline-none transition-colors focus:border-yellow-400"
                      style={{ borderColor: "rgba(0,0,0,0.2)" }}
                    />
                  </div>
                  <div className="flex flex-col gap-1">
                    <label className="text-xs font-semibold" style={{ color: "var(--av-charcoal)" }}>Email *</label>
                    <input
                      required
                      type="email"
                      value={form.email}
                      onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
                      placeholder="your@email.com"
                      className="px-3 py-2.5 text-sm rounded-md border outline-none transition-colors focus:border-yellow-400"
                      style={{ borderColor: "rgba(0,0,0,0.2)" }}
                    />
                  </div>
                </div>
                <div className="flex flex-col gap-1">
                  <label className="text-xs font-semibold" style={{ color: "var(--av-charcoal)" }}>Subject *</label>
                  <select
                    required
                    value={form.subject}
                    onChange={(e) => setForm((f) => ({ ...f, subject: e.target.value }))}
                    className="px-3 py-2.5 text-sm rounded-md border outline-none bg-white transition-colors focus:border-yellow-400"
                    style={{ borderColor: "rgba(0,0,0,0.2)" }}
                  >
                    <option value="">Select a subject</option>
                    <option>Order Inquiry</option>
                    <option>Return / Exchange</option>
                    <option>Sizing Help</option>
                    <option>Product Question</option>
                    <option>Payment Issue</option>
                    <option>Other</option>
                  </select>
                </div>
                <div className="flex flex-col gap-1">
                  <label className="text-xs font-semibold" style={{ color: "var(--av-charcoal)" }}>Message *</label>
                  <textarea
                    required
                    rows={5}
                    value={form.message}
                    onChange={(e) => setForm((f) => ({ ...f, message: e.target.value }))}
                    placeholder="Tell us how we can help..."
                    className="px-3 py-2.5 text-sm rounded-md border outline-none resize-none transition-colors focus:border-yellow-400"
                    style={{ borderColor: "rgba(0,0,0,0.2)" }}
                  />
                </div>
                <button
                  type="submit"
                  className="w-full py-3 rounded-md text-sm font-bold transition-all hover:opacity-90"
                  style={{ background: "var(--av-black)", color: "white", fontFamily: "'Montserrat', sans-serif" }}
                >
                  Send Message
                </button>
              </form>
            )}
          </div>
        </div>

        {/* FAQ Section */}
        <div id="faq">
          <div className="text-center mb-10">
            <p className="text-xs font-bold uppercase tracking-widest mb-1" style={{ color: "var(--av-gold)" }}>
              Quick Answers
            </p>
            <h2
              className="font-bold"
              style={{ fontFamily: "'Montserrat', sans-serif", fontSize: "clamp(1.5rem, 3vw, 2rem)", color: "var(--av-black)" }}
            >
              Frequently Asked Questions
            </h2>
          </div>
          <div className="max-w-3xl mx-auto space-y-3">
            {faqs.map((faq, i) => (
              <div
                key={i}
                className="border rounded-xl overflow-hidden transition-all"
                style={{ borderColor: openFaq === i ? "var(--av-gold)" : "rgba(0,0,0,0.1)" }}
              >
                <button
                  className="w-full flex items-center justify-between px-5 py-4 text-left"
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                >
                  <span
                    className="text-sm font-semibold pr-4"
                    style={{ color: openFaq === i ? "var(--av-gold)" : "var(--av-black)", fontFamily: "'Montserrat', sans-serif" }}
                  >
                    {faq.q}
                  </span>
                  <ChevronDown
                    size={18}
                    color={openFaq === i ? "var(--av-gold)" : "var(--av-charcoal)"}
                    className={`shrink-0 transition-transform duration-200 ${openFaq === i ? "rotate-180" : ""}`}
                  />
                </button>
                {openFaq === i && (
                  <div className="px-5 pb-4">
                    <p className="text-sm leading-relaxed" style={{ color: "var(--av-charcoal)" }}>{faq.a}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
