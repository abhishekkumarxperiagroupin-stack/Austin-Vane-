
  # Design Austin Vane Logo

  This is a code bundle for Design Austin Vane Logo. The original project is available at https://www.figma.com/design/NJQ2kD8B98OxkOthPEy7Vg/Design-Austin-Vane-Logo.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  